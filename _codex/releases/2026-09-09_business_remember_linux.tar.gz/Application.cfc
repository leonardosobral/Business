<cfcomponent
        displayname="Application"
        output="true"
        hint="Handle the application.">


    <!--- Set up the application. --->
    <cfset THIS.Name = "RunnerHubBusiness" />
    <cfset THIS.ApplicationTimeout = CreateTimeSpan( 2, 0, 0, 0 ) />
    <cfset THIS.SessionManagement = true />
    <cfset THIS.SetClientCookies = true />
    <cfset THIS.sessionCookie = {httpOnly=true,secure=true,sameSite="Lax"}/>
    <cfset THIS.SearchImplicitScopes = true />
    <cfset this.SessionTimeout = createTimeSpan( 1, 0, 0, 0 ) />
    <cfset THIS.datasource = "runner_dba"/>
    <cfset oldlocale = SetLocale("Portuguese (Brazilian)")>


    <!--- Define the page request properties. --->
    <cfsetting
            requesttimeout="20"
            showdebugoutput="false"
            enablecfoutputonly="false"
            />


    <cffunction
            name="OnApplicationStart"
            access="public"
            returntype="boolean"
            output="false"
            hint="Fires when the application is first created.">

        <cfset var system = createObject("java", "java.lang.System")/>
        <cfset var environment = system.getenv()/>
        <cfset var businessLocalConfig = {}/>
        <cfset var businessLocalConfigPath = getDirectoryFromPath(getCurrentTemplatePath()) & "config/business.local.cfm"/>
        <cfif fileExists(businessLocalConfigPath)>
            <cfinclude template="config/business.local.cfm"/>
            <cfif structKeyExists(VARIABLES, "businessLocalConfig") AND isStruct(VARIABLES.businessLocalConfig)>
                <cfset businessLocalConfig = duplicate(VARIABLES.businessLocalConfig)/>
            </cfif>
        </cfif>
        <cfset var openAiApiKey = structKeyExists(environment, "OPENAI_API_KEY") ? trim(environment["OPENAI_API_KEY"]) : (structKeyExists(businessLocalConfig, "openAiApiKey") ? trim(businessLocalConfig.openAiApiKey) : "")/>
        <cfset var pushDispatchSecret = structKeyExists(environment, "RR_HANDOFF_SECRET") ? trim(environment["RR_HANDOFF_SECRET"]) : (structKeyExists(businessLocalConfig, "notificationDispatchSecret") ? trim(businessLocalConfig.notificationDispatchSecret) : "")/>
        <cfset var specialGroupsSecret = structKeyExists(environment, "RR_CHAT_SPECIAL_GROUPS_SECRET") ? trim(environment["RR_CHAT_SPECIAL_GROUPS_SECRET"]) : (structKeyExists(businessLocalConfig, "specialGroupsSecret") ? trim(businessLocalConfig.specialGroupsSecret) : "")/>
        <cfset var pushDispatchUrl = structKeyExists(environment, "RR_PUSH_DISPATCH_URL") ? trim(environment["RR_PUSH_DISPATCH_URL"]) : (structKeyExists(businessLocalConfig, "notificationDispatchUrl") ? trim(businessLocalConfig.notificationDispatchUrl) : "https://roadrunners.run/api/notifications/integrations/dispatch.cfm")/>
        <cfset var notificationDispatchUrl = structKeyExists(environment, "RR_NOTIFICATION_DISPATCH_URL") ? trim(environment["RR_NOTIFICATION_DISPATCH_URL"]) : (structKeyExists(businessLocalConfig, "notificationDispatchUrl") ? trim(businessLocalConfig.notificationDispatchUrl) : "")/>
        <cfset var specialGroupsUrl = structKeyExists(environment, "RR_CHAT_SPECIAL_GROUPS_URL") ? trim(environment["RR_CHAT_SPECIAL_GROUPS_URL"]) : (structKeyExists(businessLocalConfig, "specialGroupsUrl") ? trim(businessLocalConfig.specialGroupsUrl) : "")/>
        <cfset var specialGroupsTimeoutSeconds = structKeyExists(environment, "RR_CHAT_SPECIAL_GROUPS_TIMEOUT_SECONDS") ? val(environment["RR_CHAT_SPECIAL_GROUPS_TIMEOUT_SECONDS"]) : (structKeyExists(businessLocalConfig, "specialGroupsTimeoutSeconds") ? val(businessLocalConfig.specialGroupsTimeoutSeconds) : 180)/>
        <cfset var pushDispatchTimeoutSeconds = structKeyExists(environment, "RR_PUSH_DISPATCH_TIMEOUT_SECONDS") ? val(environment["RR_PUSH_DISPATCH_TIMEOUT_SECONDS"]) : (structKeyExists(businessLocalConfig, "notificationDispatchTimeoutSeconds") ? val(businessLocalConfig.notificationDispatchTimeoutSeconds) : 20)/>
        <cfset var pushPublicKey = structKeyExists(environment, "RR_PUSH_PUBLIC_KEY") ? trim(environment["RR_PUSH_PUBLIC_KEY"]) : (structKeyExists(businessLocalConfig, "pushPublicKey") ? trim(businessLocalConfig.pushPublicKey) : "")/>
        <cfset var pushPrivateKey = structKeyExists(environment, "RR_PUSH_PRIVATE_KEY") ? trim(environment["RR_PUSH_PRIVATE_KEY"]) : (structKeyExists(businessLocalConfig, "pushPrivateKey") ? trim(businessLocalConfig.pushPrivateKey) : "")/>
        <cfset var pushSubject = structKeyExists(environment, "RR_PUSH_SUBJECT") ? trim(environment["RR_PUSH_SUBJECT"]) : (structKeyExists(businessLocalConfig, "pushSubject") ? trim(businessLocalConfig.pushSubject) : "mailto:contato@runnerhub.run")/>
        <cfset var contentAdminBaseUrl = structKeyExists(environment, "RR_CONTENT_ADMIN_BASE_URL") ? trim(environment["RR_CONTENT_ADMIN_BASE_URL"]) : "https://conteudo.roadrunners.run"/>
        <cfset var eventoApiToken = structKeyExists(environment, "RR_EVENTO_API_TOKEN") ? trim(environment["RR_EVENTO_API_TOKEN"]) : (structKeyExists(businessLocalConfig, "eventoApiToken") ? trim(businessLocalConfig.eventoApiToken) : "")/>
        <cfset var uptimeRobotApiKey = structKeyExists(environment, "UPTIMEROBOT_API_KEY") ? trim(environment["UPTIMEROBOT_API_KEY"]) : (structKeyExists(businessLocalConfig, "uptimeRobotApiKey") ? trim(businessLocalConfig.uptimeRobotApiKey) : "")/>
        <cfset var uptimeRobotApiUrl = structKeyExists(environment, "UPTIMEROBOT_API_URL") ? trim(environment["UPTIMEROBOT_API_URL"]) : (structKeyExists(businessLocalConfig, "uptimeRobotApiUrl") ? trim(businessLocalConfig.uptimeRobotApiUrl) : "https://api.uptimerobot.com/v2/getMonitors")/>
        <cfset var uptimeRobotTimeoutSeconds = structKeyExists(environment, "UPTIMEROBOT_TIMEOUT_SECONDS") ? val(environment["UPTIMEROBOT_TIMEOUT_SECONDS"]) : (structKeyExists(businessLocalConfig, "uptimeRobotTimeoutSeconds") ? val(businessLocalConfig.uptimeRobotTimeoutSeconds) : 15)/>
        <cfset var uptimeRobotCacheSeconds = structKeyExists(environment, "UPTIMEROBOT_CACHE_SECONDS") ? val(environment["UPTIMEROBOT_CACHE_SECONDS"]) : (structKeyExists(businessLocalConfig, "uptimeRobotCacheSeconds") ? val(businessLocalConfig.uptimeRobotCacheSeconds) : 120)/>
        <cfset var apiMonitorLogPath = structKeyExists(environment, "RR_BUSINESS_API_MONITOR_LOG_PATH") ? trim(environment["RR_BUSINESS_API_MONITOR_LOG_PATH"]) : (structKeyExists(businessLocalConfig, "apiMonitorLogPath") ? trim(businessLocalConfig.apiMonitorLogPath) : "/var/log/apache2/api.roadrunners.run-telemetry.log")/>
        <cfset var apiMonitorMaxBytes = structKeyExists(environment, "RR_BUSINESS_API_MONITOR_MAX_BYTES") ? val(environment["RR_BUSINESS_API_MONITOR_MAX_BYTES"]) : (structKeyExists(businessLocalConfig, "apiMonitorMaxBytes") ? val(businessLocalConfig.apiMonitorMaxBytes) : 16777216)/>
        <cfset var apiMonitorCacheSeconds = structKeyExists(environment, "RR_BUSINESS_API_MONITOR_CACHE_SECONDS") ? val(environment["RR_BUSINESS_API_MONITOR_CACHE_SECONDS"]) : (structKeyExists(businessLocalConfig, "apiMonitorCacheSeconds") ? val(businessLocalConfig.apiMonitorCacheSeconds) : 60)/>
        <cfset var cronRunnerToken = structKeyExists(environment, "RR_BUSINESS_CRON_RUNNER_TOKEN") ? trim(environment["RR_BUSINESS_CRON_RUNNER_TOKEN"]) : (structKeyExists(businessLocalConfig, "cronRunnerToken") ? trim(businessLocalConfig.cronRunnerToken) : "")/>
        <cfset var cronDefaultTimeoutSeconds = structKeyExists(environment, "RR_BUSINESS_CRON_TIMEOUT_SECONDS") ? val(environment["RR_BUSINESS_CRON_TIMEOUT_SECONDS"]) : (structKeyExists(businessLocalConfig, "cronDefaultTimeoutSeconds") ? val(businessLocalConfig.cronDefaultTimeoutSeconds) : 30)/>
        <cfset var cronSecrets = structKeyExists(businessLocalConfig, "cronSecrets") AND isStruct(businessLocalConfig.cronSecrets) ? duplicate(businessLocalConfig.cronSecrets) : {}/>
        <cfset var trelloApiKey = structKeyExists(environment, "RR_TRELLO_API_KEY") ? trim(environment["RR_TRELLO_API_KEY"]) : (structKeyExists(businessLocalConfig, "trelloApiKey") ? trim(businessLocalConfig.trelloApiKey) : "")/>
        <cfset var trelloApiToken = structKeyExists(environment, "RR_TRELLO_API_TOKEN") ? trim(environment["RR_TRELLO_API_TOKEN"]) : (structKeyExists(businessLocalConfig, "trelloApiToken") ? trim(businessLocalConfig.trelloApiToken) : "")/>
        <cfset var trelloTimeoutSeconds = structKeyExists(environment, "RR_TRELLO_TIMEOUT_SECONDS") ? val(environment["RR_TRELLO_TIMEOUT_SECONDS"]) : (structKeyExists(businessLocalConfig, "trelloTimeoutSeconds") ? val(businessLocalConfig.trelloTimeoutSeconds) : 20)/>
        <cfif NOT len(pushDispatchSecret)
            AND structKeyExists(cronSecrets, "road_runners_handoff")
            AND len(trim(cronSecrets.road_runners_handoff & ""))>
            <cfset pushDispatchSecret = trim(cronSecrets.road_runners_handoff & "")/>
        </cfif>

        <cfif NOT len(notificationDispatchUrl)>
            <cfset notificationDispatchUrl = pushDispatchUrl/>
        </cfif>
        <cfif NOT len(specialGroupsSecret)><cfset specialGroupsSecret=pushDispatchSecret/></cfif>
        <cfif NOT len(specialGroupsUrl)><cfset specialGroupsUrl=reReplace(notificationDispatchUrl,"/api/.*$","/api/chat/admin/special-groups.cfm","one")/></cfif>
        <cfif findNoCase("/api/push/send.cfm", notificationDispatchUrl)>
            <cfset notificationDispatchUrl = replaceNoCase(notificationDispatchUrl, "/api/push/send.cfm", "/api/notifications/integrations/dispatch.cfm", "one")/>
        <cfelseif findNoCase("/api/push/send-notifications.cfm", notificationDispatchUrl)>
            <cfset notificationDispatchUrl = replaceNoCase(notificationDispatchUrl, "/api/push/send-notifications.cfm", "/api/notifications/integrations/dispatch.cfm", "one")/>
        <cfelseif NOT len(notificationDispatchUrl)>
            <cfset notificationDispatchUrl = "https://roadrunners.run/api/notifications/integrations/dispatch.cfm"/>
        </cfif>

        <!--- APPLICATION VARIABLES --->
        <cfset APPLICATION.codSite = "RH"/>
        <cfset APPLICATION.vickyKnowledge = {apiKey=openAiApiKey,configured=len(openAiApiKey) GT 0}/>
        <cfset APPLICATION.nomeSite = "Runner Hub"/>
        <cfset APPLICATION.dominio = "runnerhub.run"/>
        <cfset APPLICATION.baseCanonica = "https://runnerhub.run"/>
        <cfset APPLICATION.ga = ""/>
        <cfset APPLICATION.pushDispatch = {
            url = len(notificationDispatchUrl) ? notificationDispatchUrl : "https://roadrunners.run/api/notifications/integrations/dispatch.cfm",
            secret = len(pushDispatchSecret) ? pushDispatchSecret : hash("RoadRunners::handoff::roadrunners.run::v1", "SHA-256"),
            timeoutSeconds = pushDispatchTimeoutSeconds GT 0 ? pushDispatchTimeoutSeconds : 20
        }/>
        <cfset APPLICATION.notificationDispatch = {
            url = len(notificationDispatchUrl) ? notificationDispatchUrl : "https://roadrunners.run/api/notifications/integrations/dispatch.cfm",
            secret = len(pushDispatchSecret) ? pushDispatchSecret : hash("RoadRunners::handoff::roadrunners.run::v1", "SHA-256"),
            timeoutSeconds = pushDispatchTimeoutSeconds GT 0 ? pushDispatchTimeoutSeconds : 20
        }/>
        <cfset APPLICATION.specialGroups = {
            url = specialGroupsUrl,
            secret = len(specialGroupsSecret) ? specialGroupsSecret : hash("RoadRunners::handoff::roadrunners.run::v1", "SHA-256"),
            timeoutSeconds = specialGroupsTimeoutSeconds GT 0 ? specialGroupsTimeoutSeconds : 180,
            configured = len(specialGroupsSecret) GT 0
        }/>
        <cfset APPLICATION.pwaPush = {
            enabled = (len(pushPublicKey) GT 0 AND len(pushPrivateKey) GT 0),
            publicKey = pushPublicKey,
            privateKey = pushPrivateKey,
            subject = len(pushSubject) ? pushSubject : "mailto:contato@runnerhub.run"
        }/>
        <cfset APPLICATION.contentAdmin = {
            baseUrl = len(contentAdminBaseUrl) ? contentAdminBaseUrl : "https://conteudo.roadrunners.run"
        }/>
        <cfset APPLICATION.eventoApiToken = eventoApiToken/>
        <cfset APPLICATION.uptimeRobot = {
            enabled = len(uptimeRobotApiKey) GT 0,
            apiKey = uptimeRobotApiKey,
            apiUrl = len(uptimeRobotApiUrl) ? uptimeRobotApiUrl : "https://api.uptimerobot.com/v2/getMonitors",
            timeoutSeconds = uptimeRobotTimeoutSeconds GT 0 ? uptimeRobotTimeoutSeconds : 15,
            cacheSeconds = uptimeRobotCacheSeconds GT 0 ? uptimeRobotCacheSeconds : 120
        }/>
        <cfset APPLICATION.apiMonitor = {
            enabled = len(apiMonitorLogPath) GT 0,
            logPath = apiMonitorLogPath,
            maxBytes = min(67108864, max(1048576, int(apiMonitorMaxBytes))),
            cacheSeconds = min(600, max(15, int(apiMonitorCacheSeconds)))
        }/>
        <cfset APPLICATION.cronJobs = {
            enabled = len(cronRunnerToken) GT 0,
            runnerToken = cronRunnerToken,
            defaultTimeoutSeconds = cronDefaultTimeoutSeconds GT 0 ? cronDefaultTimeoutSeconds : 30,
            secrets = cronSecrets
        }/>
        <cfset APPLICATION.trello = {
            enabled = len(trelloApiKey) GT 0 AND len(trelloApiToken) GT 0,
            apiKey = trelloApiKey,
            apiToken = trelloApiToken,
            baseUrl = "https://api.trello.com/1",
            timeoutSeconds = min(45, max(5, int(trelloTimeoutSeconds GT 0 ? trelloTimeoutSeconds : 20)))
        }/>

        <cfset APPLICATION.googleCalendar = {}/>
        <cfloop list="CLIENT_ID,CLIENT_SECRET,TOKEN_KEY" index="local.calendarSetting">
            <cfset APPLICATION.googleCalendar[local.calendarSetting] = structKeyExists(environment, "RR_GOOGLE_CALENDAR_" & local.calendarSetting) ? trim(environment["RR_GOOGLE_CALENDAR_" & local.calendarSetting]) : (structKeyExists(businessLocalConfig, "googleCalendar" & replace(local.calendarSetting, "_", "", "all")) ? trim(businessLocalConfig["googleCalendar" & replace(local.calendarSetting, "_", "", "all")]) : "")/>
        </cfloop>
        <cfset APPLICATION.googleCalendar.redirectUri = "https://business.roadrunners.run/administracao/agenda/oauth/callback.cfm"/>
        <cfset APPLICATION.googleCalendar.email = "contato@runnerhub.run"/>
        <cfset APPLICATION.googleCalendar.scopes = "openid email https://www.googleapis.com/auth/calendar.calendarlist.readonly https://www.googleapis.com/auth/calendar.events.owned"/>

        <!--- Return out. --->
        <cfreturn true />
    </cffunction>


    <cffunction
            name="OnSessionStart"
            access="public"
            returntype="void"
            output="false"
            hint="Fires when the session is first created.">

<!--- Return out. --->
        <cfreturn />
    </cffunction>


    <cffunction
            name="OnRequestStart"
            access="public"
            returntype="boolean"
            output="false"
            hint="Fires at first part of page processing.">

        <!--- Define arguments. --->
        <cfargument
                name="TargetPage"
                type="string"
                required="true"
                />

        <cfinclude template="includes/backend/business_request_identity.cfm"/>

        <cfif IsDefined("url.resetApp")>
          <cfset ApplicationStop()>
          <cfabort><!--- or, if you like, <cflocation url="index.cfm"> --->
        </cfif>

        <!---cftry>
            <cfquery>
                INSERT INTO webtumtum.logs
                (texto, tag, tipo, session_id, user_id)
                VALUES
                (<cfqueryparam cfsqltype="cf_sql_varchar" value="#cgi.script_name#"/>,
                <cfif isDefined("URL.tag")>
                    <cfqueryparam cfsqltype="cf_sql_varchar" value="#Replace(cgi.script_name, 'index.cfm', '')##URL.tag#"/>,
                <cfelse>
                    <cfqueryparam cfsqltype="cf_sql_varchar" value="#Replace(cgi.script_name, 'index.cfm', '')#"/>,
                </cfif>
                'acesso',
                <cfqueryparam cfsqltype="cf_sql_varchar" value="#SESSION.SESSIONID#"/>,
                <cfif isDefined("COOKIE.id_usuario") and len(trim(COOKIE.id_usuario)) AND isDefined("COOKIE.is_admin") and len(trim(COOKIE.is_admin))>
                    <cfqueryparam cfsqltype="cf_sql_varchar" value="#COOKIE.id_usuario#"/>
                <cfelse>
                    <cfqueryparam cfsqltype="cf_sql_varchar" value=""/>
                </cfif>)
            </cfquery>
        <cfcatch type="any">
            <cfquery>
                INSERT INTO webtumtum.logs
                (texto, tipo)
                VALUES
                (
                <cfqueryparam cfsqltype="cf_sql_varchar" value="#ARGUMENTS.TargetPage#"/>,
                'erro'
                )
            </cfquery>
        </cfcatch>
        </cftry--->

        <!--- Return out. --->
        <cfreturn true />
    </cffunction>


    <cffunction
            name="OnRequest"
            access="public"
            returntype="void"
            output="true"
            hint="Fires after pre page processing is complete.">

<!--- Define arguments. --->
        <cfargument
                name="TargetPage"
                type="string"
                required="true"
                />

<!--- Include the requested page. --->
        <cfinclude template="#ARGUMENTS.TargetPage#" />

<!--- Return out. --->
        <cfreturn />
    </cffunction>


    <cffunction
            name="OnRequestEnd"
            access="public"
            returntype="void"
            output="true"
            hint="Fires after the page processing is complete.">

<!--- Return out. --->
        <cfreturn />
    </cffunction>


    <cffunction
            name="OnSessionEnd"
            access="public"
            returntype="void"
            output="false"
            hint="Fires when the session is terminated.">

<!--- Define arguments. --->
        <cfargument
                name="SessionScope"
                type="struct"
                required="true"
                />

        <cfargument
                name="ApplicationScope"
                type="struct"
                required="false"
                default="#StructNew()#"
                />

<!--- Return out. --->
        <cfreturn />
    </cffunction>


    <cffunction
            name="OnApplicationEnd"
            access="public"
            returntype="void"
            output="false"
            hint="Fires when the application is terminated.">

<!--- Define arguments. --->
        <cfargument
                name="ApplicationScope"
                type="struct"
                required="false"
                default="#StructNew()#"
                />

<!--- Return out. --->
        <cfreturn />
    </cffunction>

</cfcomponent>
