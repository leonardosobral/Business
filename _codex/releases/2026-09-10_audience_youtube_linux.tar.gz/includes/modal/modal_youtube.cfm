<!---MODAL--->
<style>
    .video-modal-backdrop {
        background-color: #000000;
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
    }

    .video-modal-backdrop.show {
        opacity: 0.97;
    }

    .video-modal-content {
        background-color: #111111;
        color: #f5f5f5;
    }

    .video-modal-header {
        background-color: #111111;
        color: #f5f5f5;
    }

    .video-modal-header .fa-youtube,
    .video-modal-header #vName {
        color: #f5f5f5;
    }

    .video-modal-header .fa-youtube {
        color: #fab120;
    }

    .video-modal-header #vName,
    .video-modal-header #vChannel {
        color: #f5f5f5;
    }

    .video-modal-header .btn-close {
        filter: invert(1) grayscale(100%);
        opacity: 0.88;
    }

    .video-modal-header .btn-close:hover {
        opacity: 1;
    }
</style>

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
        <div class="modal-content video-modal-content">
            <div class="modal-header video-modal-header d-block py-2 border-0">
                <button type="button" class="btn-close float-end pt-2" data-mdb-ripple-init="" data-mdb-dismiss="modal" aria-label="<cfoutput>#REQUEST.t('common.loginModal.closeAria')#</cfoutput>"></button>
                <h6 class="m-0 align-items-center"><i class="fa-brands fa-youtube float-start me-2 fs-5"></i><span id="vName" class="text-truncate d-inline" style="max-width: calc(100% - 56px)"></span><span id="vChannel" class="text-truncate d-inline"></span></h6>
            </div>
            <div class="modal-body ratio ratio-16x9">
                <iframe id="iframeYoutube" class="w-100 ratio ratio-16x9 bg-black rounded-bottom-3" src="" frameborder="0" allowfullscreen allow='autoplay'></iframe>
                <video id="videoHtml5" class="d-none w-100 ratio ratio-16x9 bg-black rounded-bottom-3" controls playsinline preload="metadata"></video>
            </div>
            <!---<div class="modal-footer d-block p-1">
                <button type="button" class="btn-close float-end" data-mdb-ripple-init="" data-mdb-dismiss="modal" aria-label="Close"></button>
                <h5 id="vName"></h5>
            </div>--->
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-1.12.3.min.js" integrity="sha256-aaODHAgvwQW1bFOGXMeX+pC4PZIPsvn2h1sArYOhgXQ=" crossorigin="anonymous"></script>
<script>
    // Optional measurement adapter. The existing embed remains the playback fallback.
    var rrYoutubeMeasurement = (function () {
        var active = null, apiRequested = false;
        function stop() {
            var previous = active; active = null;
            if (!previous) return;
            if (previous.observer) previous.observer.stop();
            if (previous.player) {
                // YT.destroy removes its iframe; retain the modal's reusable placeholder.
                var frame = previous.iframe, parent = frame.parentNode;
                if (parent) {
                    var replacement = frame.cloneNode(false); replacement.src = '';
                    parent.insertBefore(replacement, frame);
                }
                try { previous.player.destroy(); } catch (_) {}
                if (frame.parentNode) frame.parentNode.removeChild(frame);
            }
        }
        function attach() {
            var binding = active;
            if (!binding || binding.player || !window.YT || !window.YT.Player) return;
            try {
                binding.player = new window.YT.Player(binding.iframe, { events: {
                    onReady: function (event) {
                        if (active !== binding || binding.observer) return;
                        try { binding.observer = window.RoadRunnersAudience.bindYouTube(event.target, binding.id); } catch (_) {}
                    },
                    onStateChange: function () {
                        if (active === binding && binding.observer) binding.observer.sample();
                    }
                } });
            } catch (_) { /* No API means no playback metrics, not a broken video. */ }
        }
        function start(frame, id) {
            if (!window.RoadRunnersAudience || !window.RoadRunnersAudience.bindYouTube) return;
            active = { iframe: frame, id: id };
            if (window.YT && window.YT.Player) { attach(); return; }
            if (apiRequested) return;
            apiRequested = true;
            var previousReady = window.onYouTubeIframeAPIReady;
            window.onYouTubeIframeAPIReady = function () {
                try { if (typeof previousReady === 'function') previousReady(); } catch (_) {}
                attach();
            };
            var script = document.createElement('script');
            script.src = 'https://www.youtube.com/iframe_api'; script.async = true;
            script.onerror = function () { apiRequested = false; script.remove(); };
            document.head.appendChild(script);
        }
        return { start: start, stop: stop };
    }());
    $(document).ready(function(){
        $("#myModal").on("hidden.bs.modal",function(){
            rrYoutubeMeasurement.stop();
            $("#iframeYoutube").attr("src","");
            var videoHtml5 = document.getElementById("videoHtml5");
            if (videoHtml5) {
                videoHtml5.pause();
                videoHtml5.removeAttribute("src");
                videoHtml5.load();
                videoHtml5.classList.add("d-none");
            }
            $(".modal-backdrop").removeClass("video-modal-backdrop");
        });

        $("#myModal").on("shown.bs.modal", function () {
            $(".modal-backdrop").last().addClass("video-modal-backdrop");
        });
    });

    function changeVideo(vId,vName,vChannel){
        rrYoutubeMeasurement.stop();
        var iframe=document.getElementById("iframeYoutube");
        var videoHtml5=document.getElementById("videoHtml5");
        if (videoHtml5) {
            videoHtml5.pause();
            videoHtml5.removeAttribute("src");
            videoHtml5.load();
            videoHtml5.classList.add("d-none");
        }
        iframe.classList.remove("d-none");
        iframe.src="https://www.youtube.com/embed/"+encodeURIComponent(vId)+"?autoplay=true&enablejsapi=1&origin="+encodeURIComponent(window.location.origin);
        $("#vName").text(vName);
        $("#vChannel").text(vChannel ? " - " + vChannel : "");
        $("#myModal").modal("show");
        if (window.RoadRunnersAudience) {
            window.RoadRunnersAudience.contentOpen("video", vId);
        }
        try { rrYoutubeMeasurement.start(iframe, vId); } catch (_) {}
    }

    function changeVideoUrl(videoUrl,vName,vChannel){
        var parsedUrl;
        var youtubeId="";

        try {
            parsedUrl=new URL(videoUrl,window.location.href);
        } catch (error) {
            return false;
        }

        if (/(^|\.)youtu\.be$/i.test(parsedUrl.hostname)) {
            youtubeId=parsedUrl.pathname.split("/").filter(Boolean)[0] || "";
        } else if (/(^|\.)(youtube\.com|youtube-nocookie\.com)$/i.test(parsedUrl.hostname)) {
            if (parsedUrl.pathname === "/watch") {
                youtubeId=parsedUrl.searchParams.get("v") || "";
            } else {
                var youtubeParts=parsedUrl.pathname.split("/").filter(Boolean);
                if (youtubeParts.length > 1 && ["embed","shorts","live"].indexOf(youtubeParts[0].toLowerCase()) >= 0) {
                    youtubeId=youtubeParts[1];
                }
            }
        }

        if (youtubeId && /^[A-Za-z0-9_-]{6,}$/.test(youtubeId)) {
            changeVideo(youtubeId,vName,vChannel);
            return true;
        }

        if (!/\.(mp4|webm|ogv|ogg)(?:$|[?#])/i.test(parsedUrl.href)) {
            return false;
        }

        rrYoutubeMeasurement.stop();
        var iframe=document.getElementById("iframeYoutube");
        var videoHtml5=document.getElementById("videoHtml5");
        iframe.src="";
        iframe.classList.add("d-none");
        videoHtml5.classList.remove("d-none");
        videoHtml5.src=parsedUrl.href;
        // Never send the media URL, query tokens or title as telemetry identifiers.
        var audienceMediaKey = parsedUrl.hostname + parsedUrl.pathname;
        var audienceMediaHash = 2166136261;
        for (var audienceMediaIndex = 0; audienceMediaIndex < audienceMediaKey.length; audienceMediaIndex++) {
            audienceMediaHash = Math.imul(audienceMediaHash ^ audienceMediaKey.charCodeAt(audienceMediaIndex), 16777619);
        }
        var audienceVideoId = "media-" + (audienceMediaHash >>> 0).toString(16);
        if (window.RoadRunnersAudience && audienceVideoId) {
            window.RoadRunnersAudience.contentOpen("video", audienceVideoId);
            window.RoadRunnersAudience.bindVideo(videoHtml5, audienceVideoId);
        }
        $("#vName").text(vName);
        $("#vChannel").text(vChannel ? " - " + vChannel : "");
        $("#myModal").modal("show");
        videoHtml5.play().catch(function(){});
        return true;
    }
</script>
