<cfparam name="VARIABLES.videoListFeaturedFirst" default="true"/>
<cfparam name="VARIABLES.videoListStartIndex" default="0"/>

<cfset VARIABLES.videoIndex = VARIABLES.videoListStartIndex>
<cfloop array="#VARIABLES.videosPaginados#" index="item">
    <cfset VARIABLES.videoIndex = VARIABLES.videoIndex + 1>
    <cfset VARIABLES.dataVideo = "">
    <cfif isDate(item.data_publicacao)>
        <cfset VARIABLES.dataVideo = lsDateFormat(item.data_publicacao, "dd/mm/yyyy")>
    </cfif>
    <cfset VARIABLES.videoTitleJs = HTMLEditFormat(JSStringFormat(item.media_titulo))>
    <cfset VARIABLES.videoChannelJs = HTMLEditFormat(JSStringFormat(item.nome_canal_video))>

    <cfoutput>
        <a class="videos-item<cfif VARIABLES.videoListFeaturedFirst AND VARIABLES.videoIndex EQ 1> is-featured</cfif>" href="##" data-audience-content-type="video" data-audience-content-id="#HTMLEditFormat(item.media_url)#" onclick="changeVideo('#HTMLEditFormat(item.media_url)#','#VARIABLES.videoTitleJs#','#VARIABLES.videoChannelJs#'); return false;">
            <div class="videos-thumb-wrap">
                <img src="https://img.youtube.com/vi/#HTMLEditFormat(item.media_url)#/sddefault.jpg" alt="#HTMLEditFormat(item.media_titulo)#" class="videos-thumb"<cfif NOT (VARIABLES.videoListFeaturedFirst AND VARIABLES.videoIndex EQ 1)> loading="lazy"</cfif> />
                <div class="videos-play-indicator">
                    <span><i class="fa-solid fa-play"></i></span>
                </div>
            </div>
            <div class="videos-item-body">
                <div class="d-flex flex-wrap gap-2 mb-2">
                    <cfif len(trim(item.nome_canal_video))>
                        <div class="videos-meta-chip">#HTMLEditFormat(item.nome_canal_video)#</div>
                    </cfif>
                    <cfif len(trim(VARIABLES.dataVideo))>
                        <div class="videos-meta-chip">#VARIABLES.dataVideo#</div>
                    </cfif>
                </div>
                <div class="videos-item-title">#HTMLEditFormat(item.media_titulo)#</div>
            </div>
        </a>
    </cfoutput>
</cfloop>
