<div class="rr-mobile-hide-sidebar">
<style>
    .home-content-item {
        display: block;
        color: #333333;
        text-decoration: none;
    }

    .home-side-block {
        border: 1px solid rgba(51, 51, 51, 0.08);
        border-radius: 10px;
        background-color: #ffffff;
    }

    .home-side-title {
        color: #333333;
        display: flex;
        align-items: center;
        gap: 0.42rem;
        font-size: 0.76rem;
        font-weight: 800;
        letter-spacing: 0.06em;
        line-height: 1;
        text-transform: uppercase;
    }

    .home-side-title i {
        color: #fab120;
        font-size: 0.82rem;
    }

    .home-side-muted {
        color: rgba(51, 51, 51, 0.72);
    }

    .home-content-item + .home-content-item {
        border-top: 1px solid rgba(51, 51, 51, 0.08);
        padding-top: 0.85rem;
        margin-top: 0.85rem;
    }

    .home-content-image {
        border-radius: 8px;
        width: 100%;
        height: auto;
        display: block;
        background-color: #efefef;
    }

    .home-content-media {
        position: relative;
    }

    .home-content-media.is-image-fallback .home-content-image {
        display: none;
    }

    .home-content-media.is-image-fallback .home-content-placeholder {
        display: flex;
    }

    .home-content-placeholder {
        width: 100%;
        aspect-ratio: 16 / 9;
        display: none;
        align-items: center;
        justify-content: center;
        border-radius: 8px;
        background:
            radial-gradient(circle at top right, rgba(250, 177, 32, 0.42), transparent 28%),
            linear-gradient(135deg, #f1f1f1 0%, #e5e5e5 100%);
        color: rgba(51, 51, 51, 0.7);
        font-size: 2rem;
    }

    .home-content-placeholder-logo {
        max-width: 64%;
        max-height: 58%;
        object-fit: contain;
    }

    .home-content-placeholder-fallback-icon {
        display: none;
    }

    .home-video-thumb {
        aspect-ratio: 16 / 9;
        object-fit: cover;
    }

    .home-video-play-indicator {
        position: absolute;
        inset: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        pointer-events: none;
    }

    .home-video-play-indicator span {
        width: 52px;
        height: 52px;
        border-radius: 999px;
        background-color: rgba(255, 255, 255, 0.74);
        color: rgba(51, 51, 51, 0.74);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 1.05rem;
        box-shadow: 0 10px 20px rgba(17, 17, 17, 0.08);
    }

    .home-video-item + .home-video-item {
        border-top: 1px solid rgba(51, 51, 51, 0.08);
        padding-top: 0.85rem;
        margin-top: 0.85rem;
    }

    .home-side-cta {
        text-decoration: none;
    }

    @media (max-width: 767.98px) {
        .rr-mobile-hide-sidebar {
            display: none !important;
        }
    }
</style>

<cfset VARIABLES.apiConteudoBase = "https://conteudo.roadrunners.run"/>
<cfset VARIABLES.apiNoticias = {}>
<cfset VARIABLES.noticias = []>
<cfset VARIABLES.noticiasCandidatas = []>
<cfset VARIABLES.noticiasLateralExcludeSlugs = {}>
<cfset VARIABLES.exibirNoticiasLateral = NOT (structKeyExists(REQUEST, "hideHomeSidebarNoticias") AND REQUEST.hideHomeSidebarNoticias)>
<cfset VARIABLES.exibirVideosLateral = NOT (structKeyExists(REQUEST, "hideHomeSidebarVideos") AND REQUEST.hideHomeSidebarVideos)>
<cfset VARIABLES.homeNewsRootPath = structKeyExists(REQUEST, "i18nBuildPath") ? REQUEST.i18nBuildPath("news") : "/noticias/"/>
<cfset VARIABLES.homeVideosRootPath = structKeyExists(REQUEST, "i18nBuildPath") ? REQUEST.i18nBuildPath("videos") : "/videos/"/>
<cfinclude template="../backend/backend_video_destaque.cfm"/>

<cfif structKeyExists(REQUEST, "homeSidebarNoticiasExcludeSlugs") AND isArray(REQUEST.homeSidebarNoticiasExcludeSlugs)>
    <cfloop array="#REQUEST.homeSidebarNoticiasExcludeSlugs#" index="VARIABLES.noticiasLateralExcludeSlug">
        <cfif len(trim(VARIABLES.noticiasLateralExcludeSlug & ""))>
            <cfset VARIABLES.noticiasLateralExcludeSlugs[lCase(trim(VARIABLES.noticiasLateralExcludeSlug & ""))] = true/>
        </cfif>
    </cfloop>
</cfif>

<cfif VARIABLES.exibirNoticiasLateral AND structKeyExists(REQUEST, "homeSidebarNoticiasOverride") AND REQUEST.homeSidebarNoticiasOverride AND structKeyExists(REQUEST, "homeSidebarNoticias") AND isArray(REQUEST.homeSidebarNoticias)>
    <cfset VARIABLES.noticiasCandidatas = duplicate(REQUEST.homeSidebarNoticias)>
<cfelseif VARIABLES.exibirNoticiasLateral>
    <cftry>
        <cfhttp url="#VARIABLES.apiConteudoBase#/rest/cmscf_api/v1/content?per_page=20&sort=published_at&dir=desc" method="get" timeout="5" result="rNoticias" />
        <cfset VARIABLES.apiNoticias = deserializeJSON(rNoticias.fileContent)>
        <cfif structKeyExists(VARIABLES.apiNoticias, "items") AND isArray(VARIABLES.apiNoticias.items)>
            <cfset VARIABLES.noticiasCandidatas = duplicate(VARIABLES.apiNoticias.items)>
        </cfif>
    <cfcatch>
        <cfset VARIABLES.noticiasCandidatas = []>
    </cfcatch>
    </cftry>
</cfif>

<cfif VARIABLES.exibirNoticiasLateral AND arrayLen(VARIABLES.noticiasCandidatas)>
    <cfloop array="#VARIABLES.noticiasCandidatas#" index="VARIABLES.noticiaLateralCandidata">
        <cfset VARIABLES.noticiaLateralCandidataSlug = isStruct(VARIABLES.noticiaLateralCandidata)
            AND structKeyExists(VARIABLES.noticiaLateralCandidata, "slug")
            ? lCase(trim(VARIABLES.noticiaLateralCandidata.slug & ""))
            : ""/>
        <cfif NOT len(VARIABLES.noticiaLateralCandidataSlug)
            OR NOT structKeyExists(VARIABLES.noticiasLateralExcludeSlugs, VARIABLES.noticiaLateralCandidataSlug)>
            <cfset arrayAppend(VARIABLES.noticias, VARIABLES.noticiaLateralCandidata)/>
        </cfif>
        <cfif arrayLen(VARIABLES.noticias) GTE 3>
            <cfbreak>
        </cfif>
    </cfloop>
</cfif>

<cfif VARIABLES.exibirVideosLateral>
    <cfquery name="qVideosHome" result="qVideosHomeMeta">
        SELECT media.media_titulo,
               media.media_url,
               media.data_publicacao,
               media.media_canal_nome AS nome_canal_video
        FROM tb_media media
        WHERE media.pub_status = TRUE
        <cfif VARIABLES.homeFeaturedVideoAvailable>
            AND media.id_media <> <cfqueryparam cfsqltype="cf_sql_integer" value="#VARIABLES.homeFeaturedVideoId#"/>
        </cfif>
        ORDER BY media.data_publicacao DESC NULLS LAST,
                 media.id_media DESC
        LIMIT 3
    </cfquery>
    <cfset logQueryDebug("qVideosHome", qVideosHomeMeta, "conteudo_lateral_api/videos_home", "sem cache", qVideosHome)/>
</cfif>

<!---
<cfset VARIABLES.adMockSlotName = "shared-sidebar-banner" />
<cfset VARIABLES.adMockFormat = "Desktop 300x250 | Mobile 320x100" />
<cfset VARIABLES.adMockContext = "Slot compartilhado de awareness para laterais editoriais, entre noticias e videos." />
<cfset VARIABLES.adMockClassName = "is-sidebar is-compact mb-2" />
<cfset VARIABLES.adMockBadge = "Slot de anuncio" />
<cfinclude template="ad_slot_mock.cfm"/>
--->

<cfif VARIABLES.exibirNoticiasLateral>
    <div class="home-side-block p-3">
        <div class="home-side-title mb-2"><i class="fa-solid fa-newspaper me-2"></i><cfoutput>#REQUEST.t("news.sidebar.title")#</cfoutput></div>

        <cfif arrayLen(VARIABLES.noticias)>
            <cfloop array="#VARIABLES.noticias#" index="item">
                <cfset VARIABLES.imagemNoticia = "">
                <cfset VARIABLES.nomeCanalNoticia = "">
                <cfset VARIABLES.logoCanalNoticia = "">
                <cfset VARIABLES.homeNoticiaPath = VARIABLES.homeNewsRootPath>
                <cfif structKeyExists(item, "featured_media") AND isStruct(item.featured_media) AND structKeyExists(item.featured_media, "url")>
                    <cfset VARIABLES.imagemNoticia = item.featured_media.url>
                    <cfif left(VARIABLES.imagemNoticia, 1) EQ "/">
                        <cfset VARIABLES.imagemNoticia = VARIABLES.apiConteudoBase & VARIABLES.imagemNoticia>
                    </cfif>
                </cfif>
                <cfif structKeyExists(item, "slug") AND len(trim(item.slug))>
                    <cfset VARIABLES.homeNewsCurrentRouteParams = structKeyExists(REQUEST, "currentRouteParams") AND isStruct(REQUEST.currentRouteParams) ? duplicate(REQUEST.currentRouteParams) : structNew() />
                    <cfset VARIABLES.homeNewsRouteParams = duplicate(VARIABLES.homeNewsCurrentRouteParams) />
                    <cfset VARIABLES.homeNewsRouteParams["tag"] = lCase(trim(item.slug)) />
                    <cfset REQUEST.currentRouteParams = VARIABLES.homeNewsRouteParams />
                    <cfset VARIABLES.homeNoticiaPath = REQUEST.i18nBuildPath("newsDetail") />
                    <cfset REQUEST.currentRouteParams = VARIABLES.homeNewsCurrentRouteParams />
                </cfif>
                <cfif structKeyExists(item, "content_type") AND isStruct(item.content_type) AND structKeyExists(item.content_type, "name") AND len(trim(item.content_type.name))>
                    <cfset VARIABLES.nomeCanalNoticia = item.content_type.name>
                    <cfif structKeyExists(item.content_type, "logo_url") AND len(trim(item.content_type.logo_url))>
                        <cfset VARIABLES.logoCanalNoticia = trim(item.content_type.logo_url)>
                    </cfif>
                </cfif>
                <cfif structKeyExists(item, "channel")>
                    <cfif isStruct(item.channel) AND structKeyExists(item.channel, "name") AND len(trim(item.channel.name))>
                        <cfset VARIABLES.nomeCanalNoticia = item.channel.name>
                        <cfif structKeyExists(item.channel, "logo_url") AND len(trim(item.channel.logo_url))>
                            <cfset VARIABLES.logoCanalNoticia = trim(item.channel.logo_url)>
                        </cfif>
                    <cfelseif isSimpleValue(item.channel) AND len(trim(item.channel))>
                        <cfset VARIABLES.nomeCanalNoticia = item.channel>
                    </cfif>
                </cfif>
                <cfif NOT len(trim(VARIABLES.nomeCanalNoticia)) AND structKeyExists(item, "canal")>
                    <cfif isStruct(item.canal) AND structKeyExists(item.canal, "name") AND len(trim(item.canal.name))>
                        <cfset VARIABLES.nomeCanalNoticia = item.canal.name>
                        <cfif structKeyExists(item.canal, "logo_url") AND len(trim(item.canal.logo_url))>
                            <cfset VARIABLES.logoCanalNoticia = trim(item.canal.logo_url)>
                        </cfif>
                    <cfelseif isSimpleValue(item.canal) AND len(trim(item.canal))>
                        <cfset VARIABLES.nomeCanalNoticia = item.canal>
                    </cfif>
                </cfif>
                <cfif NOT len(trim(VARIABLES.nomeCanalNoticia)) AND structKeyExists(item, "source")>
                    <cfif isStruct(item.source) AND structKeyExists(item.source, "name") AND len(trim(item.source.name))>
                        <cfset VARIABLES.nomeCanalNoticia = item.source.name>
                        <cfif structKeyExists(item.source, "logo_url") AND len(trim(item.source.logo_url))>
                            <cfset VARIABLES.logoCanalNoticia = trim(item.source.logo_url)>
                        </cfif>
                    <cfelseif isSimpleValue(item.source) AND len(trim(item.source))>
                        <cfset VARIABLES.nomeCanalNoticia = item.source>
                    </cfif>
                </cfif>
                <cfif NOT len(trim(VARIABLES.nomeCanalNoticia)) AND structKeyExists(item, "publisher")>
                    <cfif isStruct(item.publisher) AND structKeyExists(item.publisher, "name") AND len(trim(item.publisher.name))>
                        <cfset VARIABLES.nomeCanalNoticia = item.publisher.name>
                        <cfif structKeyExists(item.publisher, "logo_url") AND len(trim(item.publisher.logo_url))>
                            <cfset VARIABLES.logoCanalNoticia = trim(item.publisher.logo_url)>
                        </cfif>
                    <cfelseif isSimpleValue(item.publisher) AND len(trim(item.publisher))>
                        <cfset VARIABLES.nomeCanalNoticia = item.publisher>
                    </cfif>
                </cfif>
                <cfif len(trim(VARIABLES.logoCanalNoticia)) AND left(VARIABLES.logoCanalNoticia, 1) EQ "/">
                    <cfset VARIABLES.logoCanalNoticia = VARIABLES.apiConteudoBase & VARIABLES.logoCanalNoticia>
                </cfif>

                <cfoutput>
                    <a class="home-content-item" href="#VARIABLES.homeNoticiaPath#" data-audience-content-type="news" data-audience-content-id="#HTMLEditFormat(structKeyExists(item, "id") AND isSimpleValue(item.id) AND len(trim(item.id & "")) ? trim(item.id & "") : item.slug)#">
                        <cfif len(trim(VARIABLES.imagemNoticia))>
                            <div class="home-content-media mb-2">
                                <img src="#VARIABLES.imagemNoticia#" alt="#item.title#" class="home-content-image" onerror="this.onerror=null; this.parentNode.classList.add('is-image-fallback');" />
                                <div class="home-content-placeholder">
                                    <cfif len(trim(VARIABLES.logoCanalNoticia))>
                                        <img src="#VARIABLES.logoCanalNoticia#" alt="#HTMLEditFormat(len(trim(VARIABLES.nomeCanalNoticia)) ? VARIABLES.nomeCanalNoticia : "Road Runners Press")#" class="home-content-placeholder-logo" loading="lazy" onerror="this.onerror=null; this.style.display='none'; this.nextElementSibling.style.display='inline-flex';" />
                                        <i class="fa-solid fa-person-running home-content-placeholder-fallback-icon"></i>
                                    <cfelse>
                                        <i class="fa-solid fa-person-running"></i>
                                    </cfif>
                                </div>
                            </div>
                        <cfelse>
                            <div class="home-content-placeholder mb-2" style="display:flex;">
                                <cfif len(trim(VARIABLES.logoCanalNoticia))>
                                    <img src="#VARIABLES.logoCanalNoticia#" alt="#HTMLEditFormat(len(trim(VARIABLES.nomeCanalNoticia)) ? VARIABLES.nomeCanalNoticia : "Road Runners Press")#" class="home-content-placeholder-logo" loading="lazy" onerror="this.onerror=null; this.style.display='none'; this.nextElementSibling.style.display='inline-flex';" />
                                    <i class="fa-solid fa-person-running home-content-placeholder-fallback-icon"></i>
                                <cfelse>
                                    <i class="fa-solid fa-person-running"></i>
                                </cfif>
                            </div>
                        </cfif>
                        <div class="small home-side-muted mb-1">
                            #len(trim(VARIABLES.nomeCanalNoticia)) ? VARIABLES.nomeCanalNoticia : "Road Runners Press"#
                        </div>
                        <div class="fw-semibold">#item.title#</div>
                    </a>
                </cfoutput>
            </cfloop>
            <div class="mt-3">
                <a href="<cfoutput>#VARIABLES.homeNewsRootPath#</cfoutput>" class="btn btn-secondary btn-sm w-100 home-side-cta"><i class="fa-solid fa-newspaper me-1"></i><cfoutput>#REQUEST.t("news.sidebar.viewAll")#</cfoutput></a>
            </div>
        <cfelse>
            <div class="small home-side-muted"><cfoutput>#REQUEST.t("news.sidebar.empty")#</cfoutput></div>
        </cfif>
    </div>
</cfif>

<cfif VARIABLES.exibirVideosLateral>
    <div class="home-side-block p-3<cfif VARIABLES.exibirNoticiasLateral> mt-2</cfif>">
        <div class="home-side-title mb-2"><i class="fa-brands fa-youtube me-2"></i><cfoutput>#REQUEST.t("videos.sidebar.latestTitle")#</cfoutput></div>

        <cfif qVideosHome.recordcount>
            <cfoutput query="qVideosHome">
                <cfset VARIABLES.videoTitleJs = HTMLEditFormat(JSStringFormat(media_titulo))>
                <cfset VARIABLES.videoChannelJs = HTMLEditFormat(JSStringFormat(nome_canal_video))>
                <a class="home-content-item home-video-item" href="##" data-audience-content-type="video" data-audience-content-id="#HTMLEditFormat(media_url)#" onclick="changeVideo('#HTMLEditFormat(media_url)#','#VARIABLES.videoTitleJs#','#VARIABLES.videoChannelJs#'); return false;">
                    <div class="home-content-media mb-2">
                        <img src="https://img.youtube.com/vi/#HTMLEditFormat(media_url)#/sddefault.jpg" alt="#HTMLEditFormat(media_titulo)#" class="home-content-image home-video-thumb" onerror="this.onerror=null; this.parentNode.classList.add('is-image-fallback');" />
                        <div class="home-content-placeholder">
                            <i class="fa-solid fa-person-running"></i>
                        </div>
                        <div class="home-video-play-indicator">
                            <span><i class="fa-solid fa-play"></i></span>
                        </div>
                    </div>
                    <cfif len(trim(nome_canal_video))>
                        <div class="small home-side-muted mb-1">#HTMLEditFormat(nome_canal_video)#</div>
                    </cfif>
                    <div class="fw-semibold mb-1">#HTMLEditFormat(media_titulo)#</div>
                </a>
            </cfoutput>
            <div class="mt-3">
                <a href="<cfoutput>#VARIABLES.homeVideosRootPath#</cfoutput>" class="btn btn-secondary btn-sm w-100 home-side-cta"><i class="fa-brands fa-youtube me-1"></i><cfoutput>#REQUEST.t("videos.sidebar.viewAll")#</cfoutput></a>
            </div>
        <cfelse>
            <div class="small home-side-muted"><cfoutput>#REQUEST.t("videos.sidebar.empty")#</cfoutput></div>
        </cfif>
    </div>
</cfif>
</div>
