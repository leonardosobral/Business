<cfparam name="VARIABLES.newsListFeaturedFirst" default="true"/>
<cfparam name="VARIABLES.newsListStartIndex" default="0"/>

<cfset VARIABLES.noticiaIndex = VARIABLES.newsListStartIndex>
<cfloop array="#VARIABLES.noticiasPaginadas#" index="item">
    <cfset VARIABLES.noticiaIndex = VARIABLES.noticiaIndex + 1>
    <cfset VARIABLES.imagemNoticia = "">
    <cfset VARIABLES.dataNoticia = "">
    <cfset VARIABLES.canalNoticia = "">
    <cfset VARIABLES.canalNoticiaLogo = "">
    <cfset VARIABLES.newsCardPath = "">

    <cfif structKeyExists(item, "featured_media") AND isStruct(item.featured_media) AND structKeyExists(item.featured_media, "url")>
        <cfset VARIABLES.imagemNoticia = item.featured_media.url>
        <cfif left(VARIABLES.imagemNoticia, 1) EQ "/">
            <cfset VARIABLES.imagemNoticia = VARIABLES.apiConteudoBase & VARIABLES.imagemNoticia>
        </cfif>
    </cfif>

    <cfif structKeyExists(item, "content_type") AND isStruct(item.content_type) AND structKeyExists(item.content_type, "name") AND len(trim(item.content_type.name))>
        <cfset VARIABLES.canalNoticia = item.content_type.name>
        <cfif structKeyExists(item.content_type, "logo_url") AND len(trim(item.content_type.logo_url))>
            <cfset VARIABLES.canalNoticiaLogo = trim(item.content_type.logo_url)>
        </cfif>
    <cfelseif structKeyExists(item, "channel") AND isStruct(item.channel) AND structKeyExists(item.channel, "name") AND len(trim(item.channel.name))>
        <cfset VARIABLES.canalNoticia = item.channel.name>
        <cfif structKeyExists(item.channel, "logo_url") AND len(trim(item.channel.logo_url))>
            <cfset VARIABLES.canalNoticiaLogo = trim(item.channel.logo_url)>
        </cfif>
    <cfelseif structKeyExists(item, "channel") AND isSimpleValue(item.channel) AND len(trim(item.channel))>
        <cfset VARIABLES.canalNoticia = item.channel>
    </cfif>
    <cfif len(trim(VARIABLES.canalNoticiaLogo)) AND left(VARIABLES.canalNoticiaLogo, 1) EQ "/">
        <cfset VARIABLES.canalNoticiaLogo = VARIABLES.apiConteudoBase & VARIABLES.canalNoticiaLogo>
    </cfif>

    <cfif structKeyExists(item, "published_at") AND len(trim(item.published_at))>
        <cftry>
            <cfset VARIABLES.dataNoticia = lsDateFormat(parseDateTime(left(item.published_at, 10)), "dd/mm/yyyy")>
        <cfcatch>
            <cfset VARIABLES.dataNoticia = "">
        </cfcatch>
        </cftry>
    </cfif>

    <cfif structKeyExists(item, "slug") AND len(trim(item.slug)) AND structKeyExists(REQUEST, "i18nBuildPath")>
        <cfset VARIABLES.newsCardCurrentRouteParams = structKeyExists(REQUEST, "currentRouteParams") AND isStruct(REQUEST.currentRouteParams) ? duplicate(REQUEST.currentRouteParams) : structNew() />
        <cfset VARIABLES.newsCardRouteParams = duplicate(VARIABLES.newsCardCurrentRouteParams) />
        <cfset VARIABLES.newsCardRouteParams["tag"] = lCase(trim(item.slug)) />
        <cfset REQUEST.currentRouteParams = VARIABLES.newsCardRouteParams />
        <cfset VARIABLES.newsCardPath = REQUEST.i18nBuildPath("newsDetail") />
        <cfset REQUEST.currentRouteParams = VARIABLES.newsCardCurrentRouteParams />
    <cfelseif structKeyExists(item, "slug") AND len(trim(item.slug))>
        <cfset VARIABLES.newsCardPath = VARIABLES.newsRootUrl & item.slug & "/" />
    <cfelse>
        <cfset VARIABLES.newsCardPath = VARIABLES.newsRootUrl />
    </cfif>

    <cfoutput>
        <a class="news-item<cfif VARIABLES.newsListFeaturedFirst AND VARIABLES.noticiaIndex EQ 1> is-featured</cfif>" href="#HTMLEditFormat(VARIABLES.newsCardPath)#" data-audience-content-type="news" data-audience-content-id="#HTMLEditFormat(structKeyExists(item, "id") AND isSimpleValue(item.id) AND len(trim(item.id & "")) ? trim(item.id & "") : item.slug)#">
            <cfif len(trim(VARIABLES.imagemNoticia))>
                <img src="#HTMLEditFormat(VARIABLES.imagemNoticia)#" alt="#HTMLEditFormat(item.title)#" class="news-thumb"<cfif NOT (VARIABLES.newsListFeaturedFirst AND VARIABLES.noticiaIndex EQ 1)> loading="lazy"</cfif> />
            <cfelse>
                <div class="news-list-placeholder">
                    <cfif len(trim(VARIABLES.canalNoticiaLogo))>
                        <img src="#HTMLEditFormat(VARIABLES.canalNoticiaLogo)#" alt="#HTMLEditFormat(len(trim(VARIABLES.canalNoticia)) ? VARIABLES.canalNoticia : "Road Runners Press")#" class="news-list-placeholder-logo" loading="lazy" onerror="this.onerror=null; this.style.display='none'; this.nextElementSibling.style.display='inline-flex';" />
                        <i class="fa-solid fa-person-running news-list-placeholder-fallback-icon"></i>
                    <cfelse>
                        <i class="fa-solid fa-person-running"></i>
                    </cfif>
                </div>
            </cfif>
            <div class="news-item-body">
                <div class="d-flex flex-wrap gap-2 mb-2">
                    <cfif len(trim(VARIABLES.canalNoticia))>
                        <div class="news-meta-chip is-channel">#VARIABLES.canalNoticia#</div>
                    </cfif>
                    <div class="news-meta-chip">
                        <cfif structKeyExists(item, "category") AND isStruct(item.category) AND structKeyExists(item.category, "name")>
                            #item.category.name#
                        <cfelse>
                            Road Runners Press
                        </cfif>
                    </div>
                    <cfif len(trim(VARIABLES.dataNoticia))>
                        <div class="news-meta-chip">#VARIABLES.dataNoticia#</div>
                    </cfif>
                </div>
                <div class="news-item-title">#item.title#</div>
                <cfif structKeyExists(item, "excerpt") AND len(trim(item.excerpt))>
                    <div class="news-item-excerpt">#item.excerpt#</div>
                </cfif>
            </div>
        </a>
    </cfoutput>
</cfloop>
