<cfprocessingdirective pageencoding="utf-8"/>
<cfsetting showdebugoutput="false"/>

<cfset VARIABLES.template = "/"/>
<cfset VARIABLES.routeKey = "home"/>
<cfset REQUEST.currentRouteKey = VARIABLES.routeKey/>
<cfset REQUEST.currentRouteParams = {}/>

<cfinclude template="../includes/estrutura/variaveis.cfm"/>
<cfinclude template="../includes/backend/backend.cfm"/>
<cfinclude template="../includes/backend/backend_login.cfm"/>
<cfinclude template="../includes/backend/backend_conteudo_canais.cfm"/>
<cfinclude template="../includes/backend/backend_video_destaque.cfm"/>

<cfset VARIABLES.apiConteudoBase = "https://conteudo.roadrunners.run"/>
<cfset VARIABLES.homeNoticias = []/>
<cfset VARIABLES.homeNoticiaDestaque = {}/>
<cfset VARIABLES.homeNoticiasRecentes = []/>
<cfset VARIABLES.homeNoticiaDestaqueSlug = ""/>
<cfset VARIABLES.homeNewsEligibleChannelSlugs = structKeyExists(REQUEST, "contentChannelHomeFeaturedSlugs") AND isArray(REQUEST.contentChannelHomeFeaturedSlugs) ? duplicate(REQUEST.contentChannelHomeFeaturedSlugs) : []/>
<cfset VARIABLES.homeNewsCacheTtlMinutes = structKeyExists(REQUEST, "currentEnvironment") AND REQUEST.currentEnvironment EQ "dev" ? 1 : 5/>
<cfset VARIABLES.homeNewsCachePrefix = "rr_home_news_#REQUEST.lang#_"/>
<cfset VARIABLES.homeNewsUsesFeaturedVideo = VARIABLES.homeFeaturedVideoAvailable/>
<cfset VARIABLES.homeNewsRecentLimit = VARIABLES.homeNewsUsesFeaturedVideo ? 2 : 3/>
<cfset qHomeFeaturedVideoEvent = queryNew("id_evento,nome_evento,cidade,estado,pais,data_inicial,data_final,tag,status_evento,categorias,lista_percursos,badges,concluintes,cupom")/>

<cfif VARIABLES.homeNewsUsesFeaturedVideo AND VARIABLES.homeFeaturedVideo.eventId GT 0>
    <cfquery name="qHomeFeaturedVideoEvent" cachedwithin="#VARIABLES.homeFeaturedVideoCacheTtl#" result="qHomeFeaturedVideoEventMeta">
        SELECT evt.id_evento,
               evt.nome_evento,
               evt.cidade,
               evt.estado,
               evt.pais,
               evt.data_inicial,
               evt.data_final,
               evt.tag,
               evt.status_evento,
               evt.categorias,
               evt.lista_percursos,
               evt.badges,
               evt.concluintes,
               evt.cupom
        FROM vw_evento_corridas evt
        WHERE evt.id_evento = <cfqueryparam cfsqltype="cf_sql_integer" value="#VARIABLES.homeFeaturedVideo.eventId#"/>
        LIMIT 1
    </cfquery>
    <cfset logQueryDebug("qHomeFeaturedVideoEvent", qHomeFeaturedVideoEventMeta, "home/video_destaque_evento", VARIABLES.homeFeaturedVideoCacheLabel, qHomeFeaturedVideoEvent)/>
</cfif>

<cfif NOT structKeyExists(APPLICATION, "externalHttpCache") OR NOT isStruct(APPLICATION.externalHttpCache)>
    <cfset APPLICATION.externalHttpCache = {}/>
</cfif>

<cfif NOT VARIABLES.homeNewsUsesFeaturedVideo>
    <cftry>
        <cfset VARIABLES.homeNewsFeaturedCacheKey = VARIABLES.homeNewsCachePrefix & "featured"/>
        <cfif structKeyExists(APPLICATION.externalHttpCache, VARIABLES.homeNewsFeaturedCacheKey)
            AND isStruct(APPLICATION.externalHttpCache[VARIABLES.homeNewsFeaturedCacheKey])
            AND structKeyExists(APPLICATION.externalHttpCache[VARIABLES.homeNewsFeaturedCacheKey], "expiresAt")
            AND APPLICATION.externalHttpCache[VARIABLES.homeNewsFeaturedCacheKey].expiresAt GT now()
            AND structKeyExists(APPLICATION.externalHttpCache[VARIABLES.homeNewsFeaturedCacheKey], "payload")>
            <cfset VARIABLES.apiNoticiaDestaqueHome = APPLICATION.externalHttpCache[VARIABLES.homeNewsFeaturedCacheKey].payload/>
        <cfelse>
            <cfhttp url="#VARIABLES.apiConteudoBase#/rest/cmscf_api/v1/content?per_page=20&sort=published_at&dir=desc&featured=1" method="get" timeout="5" result="rHomeNoticiaDestaque"/>
            <cfset VARIABLES.apiNoticiaDestaqueHome = deserializeJSON(rHomeNoticiaDestaque.fileContent)/>
            <cfset APPLICATION.externalHttpCache[VARIABLES.homeNewsFeaturedCacheKey] = {
                payload = VARIABLES.apiNoticiaDestaqueHome,
                expiresAt = dateAdd("n", VARIABLES.homeNewsCacheTtlMinutes, now())
            }/>
        </cfif>
        <cfif structKeyExists(VARIABLES.apiNoticiaDestaqueHome, "items") AND isArray(VARIABLES.apiNoticiaDestaqueHome.items) AND arrayLen(VARIABLES.apiNoticiaDestaqueHome.items)>
            <cfset VARIABLES.homeNoticiaDestaque = VARIABLES.apiNoticiaDestaqueHome.items[1]/>
            <cfif structKeyExists(VARIABLES.homeNoticiaDestaque, "slug")>
                <cfset VARIABLES.homeNoticiaDestaqueSlug = trim(VARIABLES.homeNoticiaDestaque.slug)/>
            </cfif>
        </cfif>
    <cfcatch>
        <cfset VARIABLES.homeNoticiaDestaque = {}/>
        <cfset VARIABLES.homeNoticiaDestaqueSlug = ""/>
    </cfcatch>
    </cftry>
</cfif>

<cfif arrayLen(VARIABLES.homeNewsEligibleChannelSlugs)>

    <cftry>
        <cfset VARIABLES.homeNewsRecentCacheKey = VARIABLES.homeNewsCachePrefix & "recent"/>
        <cfif structKeyExists(APPLICATION.externalHttpCache, VARIABLES.homeNewsRecentCacheKey)
            AND isStruct(APPLICATION.externalHttpCache[VARIABLES.homeNewsRecentCacheKey])
            AND structKeyExists(APPLICATION.externalHttpCache[VARIABLES.homeNewsRecentCacheKey], "expiresAt")
            AND APPLICATION.externalHttpCache[VARIABLES.homeNewsRecentCacheKey].expiresAt GT now()
            AND structKeyExists(APPLICATION.externalHttpCache[VARIABLES.homeNewsRecentCacheKey], "payload")>
            <cfset VARIABLES.apiNoticiasHome = APPLICATION.externalHttpCache[VARIABLES.homeNewsRecentCacheKey].payload/>
        <cfelse>
            <cfhttp url="#VARIABLES.apiConteudoBase#/rest/cmscf_api/v1/content?per_page=50&sort=published_at&dir=desc" method="get" timeout="5" result="rHomeNoticias"/>
            <cfset VARIABLES.apiNoticiasHome = deserializeJSON(rHomeNoticias.fileContent)/>
            <cfset APPLICATION.externalHttpCache[VARIABLES.homeNewsRecentCacheKey] = {
                payload = VARIABLES.apiNoticiasHome,
                expiresAt = dateAdd("n", VARIABLES.homeNewsCacheTtlMinutes, now())
            }/>
        </cfif>
        <cfif structKeyExists(VARIABLES.apiNoticiasHome, "items") AND isArray(VARIABLES.apiNoticiasHome.items)>
            <cfloop array="#VARIABLES.apiNoticiasHome.items#" index="item">
                <cfset VARIABLES.homeNewsCandidateChannelSlug = ""/>
                <cfif structKeyExists(item, "content_type") AND isStruct(item.content_type) AND structKeyExists(item.content_type, "slug") AND len(trim(item.content_type.slug))>
                    <cfset VARIABLES.homeNewsCandidateChannelSlug = lCase(trim(item.content_type.slug))/>
                <cfelseif structKeyExists(item, "channel") AND isStruct(item.channel) AND structKeyExists(item.channel, "slug") AND len(trim(item.channel.slug))>
                    <cfset VARIABLES.homeNewsCandidateChannelSlug = lCase(trim(item.channel.slug))/>
                </cfif>
                <cfif len(trim(VARIABLES.homeNewsCandidateChannelSlug)) AND arrayFindNoCase(VARIABLES.homeNewsEligibleChannelSlugs, VARIABLES.homeNewsCandidateChannelSlug) AND NOT (len(trim(VARIABLES.homeNoticiaDestaqueSlug)) AND structKeyExists(item, "slug") AND item.slug EQ VARIABLES.homeNoticiaDestaqueSlug)>
                    <cfset arrayAppend(VARIABLES.homeNoticiasRecentes, item)/>
                    <cfif arrayLen(VARIABLES.homeNoticiasRecentes) GTE VARIABLES.homeNewsRecentLimit>
                        <cfbreak>
                    </cfif>
                </cfif>
            </cfloop>
        </cfif>
    <cfcatch>
        <cfset VARIABLES.homeNoticiasRecentes = []/>
    </cfcatch>
    </cftry>
</cfif>

<cfif VARIABLES.homeNewsUsesFeaturedVideo>
    <cfloop array="#VARIABLES.homeNoticiasRecentes#" index="item">
        <cfset arrayAppend(VARIABLES.homeNoticias, item)/>
        <cfif arrayLen(VARIABLES.homeNoticias) GTE VARIABLES.homeNewsRecentLimit>
            <cfbreak>
        </cfif>
    </cfloop>
<cfelseif isStruct(VARIABLES.homeNoticiaDestaque) AND structCount(VARIABLES.homeNoticiaDestaque)>
    <cfset arrayAppend(VARIABLES.homeNoticias, VARIABLES.homeNoticiaDestaque)/>
<cfelseif arrayLen(VARIABLES.homeNoticiasRecentes)>
    <cfset arrayAppend(VARIABLES.homeNoticias, VARIABLES.homeNoticiasRecentes[1])/>
    <cfset arrayDeleteAt(VARIABLES.homeNoticiasRecentes, 1)/>
</cfif>

<cfif NOT VARIABLES.homeNewsUsesFeaturedVideo>
    <cfloop array="#VARIABLES.homeNoticiasRecentes#" index="item">
        <cfset arrayAppend(VARIABLES.homeNoticias, item)/>
        <cfif arrayLen(VARIABLES.homeNoticias) GTE 3>
            <cfbreak>
        </cfif>
    </cfloop>
</cfif>

<cfsavecontent variable="VARIABLES.homeNewsHtml">
    <section data-home-async="news" aria-busy="false">
        <div class="home-content-panel-header">
            <div class="home-content-panel-title">
                <cfif VARIABLES.homeNewsUsesFeaturedVideo>
                    <i class="fa-brands fa-youtube me-2"></i>RunTV
                <cfelse>
                    <i class="fa-solid fa-newspaper me-2"></i><cfoutput>#REQUEST.t("news.sidebar.title")#</cfoutput>
                </cfif>
            </div>
            <a href="<cfoutput>#REQUEST.i18nBuildPath("news")#</cfoutput>" class="home-content-panel-cta"><cfoutput>#REQUEST.t("news.sidebar.viewAll")#</cfoutput></a>
        </div>

        <cfif VARIABLES.homeNewsUsesFeaturedVideo OR arrayLen(VARIABLES.homeNoticias)>
            <div class="home-news-layout">
                <cfif VARIABLES.homeNewsUsesFeaturedVideo>
                    <cfset VARIABLES.homeFeaturedVideoTitleJs = HTMLEditFormat(JSStringFormat(VARIABLES.homeFeaturedVideo.title))/>
                    <cfset VARIABLES.homeFeaturedVideoChannelJs = HTMLEditFormat(JSStringFormat(VARIABLES.homeFeaturedVideo.channel))/>
                    <div class="home-featured-video-slot">
                        <div class="home-content-card is-featured home-news-featured home-video-card">
                            <cfoutput>
                                <a href="##" class="home-featured-video-link" data-audience-content-type="video" data-audience-content-id="#HTMLEditFormat(VARIABLES.homeFeaturedVideo.url)#" onclick="changeVideo('#HTMLEditFormat(VARIABLES.homeFeaturedVideo.url)#','#VARIABLES.homeFeaturedVideoTitleJs#','#VARIABLES.homeFeaturedVideoChannelJs#'); return false;">
                                    <div class="home-video-thumb-wrap">
                                        <div class="home-content-card-media">
                                            <img src="https://img.youtube.com/vi/#HTMLEditFormat(VARIABLES.homeFeaturedVideo.url)#/sddefault.jpg" alt="#HTMLEditFormat(VARIABLES.homeFeaturedVideo.title)#" class="home-content-card-image" onerror="this.onerror=null; this.parentNode.classList.add('is-image-fallback');" />
                                            <div class="home-content-card-placeholder">
                                                <i class="fa-solid fa-person-running"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="home-content-card-body">
                                        <cfif len(trim(VARIABLES.homeFeaturedVideo.channel))>
                                            <div class="home-content-card-kicker">#HTMLEditFormat(VARIABLES.homeFeaturedVideo.channel)#</div>
                                        </cfif>
                                        <h3 class="home-content-card-title">#HTMLEditFormat(VARIABLES.homeFeaturedVideo.title)#</h3>
                                    </div>
                                </a>
                            </cfoutput>
                            <cfif qHomeFeaturedVideoEvent.recordcount>
                                <div class="home-featured-video-event-card">
                                    <cfloop query="qHomeFeaturedVideoEvent">
                                        <cfset VARIABLES.homeCompactEventMode = isDate(data_final) AND data_final GTE now() ? "proximos" : "resultados"/>
                                        <cfset VARIABLES.homeCompactEventIsSponsored = false/>
                                        <cfset VARIABLES.homeCompactEventExtraClass = ""/>
                                        <cfinclude template="../includes/estrutura/home_event_compact_card.cfm"/>
                                    </cfloop>
                                </div>
                            </cfif>
                        </div>
                    </div>
                <cfelse>
                    <cfset item = VARIABLES.homeNoticias[1]/>
                    <cfinclude template="../includes/estrutura/home_news_card_vars.cfm"/>
                    <cfoutput>
                        <a href="#HTMLEditFormat(VARIABLES.homeNewsLink)#" class="home-content-card is-featured home-news-featured" data-audience-content-type="news" data-audience-content-id="#HTMLEditFormat(structKeyExists(item, "id") AND isSimpleValue(item.id) AND len(trim(item.id & "")) ? trim(item.id & "") : item.slug)#">
                    </cfoutput>
                            <cfinclude template="../includes/estrutura/home_news_card_media.cfm"/>
                    <cfoutput>
                            <div class="home-content-card-body">
                                <div class="home-content-card-kicker">#HTMLEditFormat(VARIABLES.homeNewsChannel)#</div>
                                <h3 class="home-content-card-title">#HTMLEditFormat(VARIABLES.homeNewsTitle)#</h3>
                                <cfif len(trim(VARIABLES.homeNewsSummary))>
                                    <p class="home-content-card-summary">#HTMLEditFormat(VARIABLES.homeNewsSummary)#</p>
                                </cfif>
                            </div>
                        </a>
                    </cfoutput>
                </cfif>

                <cfset VARIABLES.homeNewsStackStart = VARIABLES.homeNewsUsesFeaturedVideo ? 1 : 2/>
                <cfset VARIABLES.homeNewsStackEnd = VARIABLES.homeNewsUsesFeaturedVideo ? min(arrayLen(VARIABLES.homeNoticias), 2) : min(arrayLen(VARIABLES.homeNoticias), 3)/>
                <cfif VARIABLES.homeNewsStackStart LTE VARIABLES.homeNewsStackEnd>
                    <div class="home-news-top-stack">
                        <cfloop from="#VARIABLES.homeNewsStackStart#" to="#VARIABLES.homeNewsStackEnd#" index="homeNewsIndex">
                            <cfset item = VARIABLES.homeNoticias[homeNewsIndex]/>
                            <cfinclude template="../includes/estrutura/home_news_card_vars.cfm"/>
                            <cfoutput>
                                <a href="#HTMLEditFormat(VARIABLES.homeNewsLink)#" class="home-content-card" data-audience-content-type="news" data-audience-content-id="#HTMLEditFormat(structKeyExists(item, "id") AND isSimpleValue(item.id) AND len(trim(item.id & "")) ? trim(item.id & "") : item.slug)#">
                            </cfoutput>
                                    <cfinclude template="../includes/estrutura/home_news_card_media.cfm"/>
                            <cfoutput>
                                    <div class="home-content-card-body">
                                        <div class="home-content-card-kicker">#HTMLEditFormat(VARIABLES.homeNewsChannel)#</div>
                                        <h3 class="home-content-card-title">#HTMLEditFormat(VARIABLES.homeNewsTitle)#</h3>
                                    </div>
                                </a>
                            </cfoutput>
                        </cfloop>
                    </div>
                </cfif>
            </div>
        <cfelse>
            <div class="small home-hero-muted"><cfoutput>#REQUEST.t("news.sidebar.empty")#</cfoutput></div>
        </cfif>
    </section>
</cfsavecontent>

<cfcontent type="text/html; charset=utf-8" reset="true"><cfoutput>#trim(VARIABLES.homeNewsHtml)#</cfoutput><cfabort>
