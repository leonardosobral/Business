<cfprocessingdirective pageencoding="utf-8"/>

<!--- NORMALIZA PARAMETROS DA BUSCA DE NOTICIAS --->
<cfparam name="URL.busca" default=""/>
<cfparam name="URL.termo" default=""/>
<cfparam name="URL.busca_tipo" default="noticias"/>
<cfparam name="URL.i18n_lang" default=""/>
<cfparam name="URL.busca_log_id" default=""/>

<!--- CARREGA TRADUCOES E ROTAS LOCALIZADAS --->
<cfinclude template="../includes/estrutura/variaveis.cfm"/>

<!--- DEFINE O CMS REMOTO E O TERMO USADO NA CONSULTA --->
<cfset VARIABLES.apiConteudoBase = "https://conteudo.roadrunners.run"/>
<cfset VARIABLES.buscaNoticiasTermo = len(trim(URL.busca)) ? trim(URL.busca) : trim(URL.termo)/>
<cfscript>
// PREPARA O TERMO FORMATADO PARA A MENSAGEM DE ESTADO VAZIO
VARIABLES.buscaNoticiasTermoDisplay = "";
VARIABLES.buscaNoticiasTermoPalavras = [];
buscaNoticiasPalavra = "";

for (buscaNoticiasPalavra in listToArray(lCase(VARIABLES.buscaNoticiasTermo), " ")) {
    if (len(trim(buscaNoticiasPalavra))) {
        arrayAppend(
            VARIABLES.buscaNoticiasTermoPalavras,
            uCase(left(buscaNoticiasPalavra, 1)) & mid(buscaNoticiasPalavra, 2, len(buscaNoticiasPalavra))
        );
    }
}

VARIABLES.buscaNoticiasTermoDisplay = arrayToList(VARIABLES.buscaNoticiasTermoPalavras, " ");
</cfscript>
<cfset VARIABLES.buscaNoticiasItens = []>
<cfset VARIABLES.buscaNoticiasTotal = 0>
<cfset VARIABLES.buscaNoticiasErro = "">
<cfset VARIABLES.buscaNoticiasPerPage = lCase(trim(URL.busca_tipo)) EQ "noticias" ? 40 : 12>

<!--- BUSCA NOTICIAS NO CMS REMOTO APENAS QUANDO HA TERMO LIVRE --->
<cfif len(trim(VARIABLES.buscaNoticiasTermo))>
    <cftry>
        <cfhttp url="#VARIABLES.apiConteudoBase#/rest/cmscf_api/v1/content?q=#urlEncodedFormat(VARIABLES.buscaNoticiasTermo)#&per_page=#VARIABLES.buscaNoticiasPerPage#&sort=published_at&dir=desc" method="get" timeout="8" result="rBuscaNoticias" />
        <cfset VARIABLES.buscaNoticiasPayload = deserializeJSON(rBuscaNoticias.fileContent)>
        <cfif isStruct(VARIABLES.buscaNoticiasPayload) AND structKeyExists(VARIABLES.buscaNoticiasPayload, "items") AND isArray(VARIABLES.buscaNoticiasPayload.items)>
            <cfset VARIABLES.buscaNoticiasItens = VARIABLES.buscaNoticiasPayload.items>
        </cfif>
        <cfif isStruct(VARIABLES.buscaNoticiasPayload) AND structKeyExists(VARIABLES.buscaNoticiasPayload, "pagination") AND isStruct(VARIABLES.buscaNoticiasPayload.pagination)>
            <cfif structKeyExists(VARIABLES.buscaNoticiasPayload.pagination, "total_items") AND isNumeric(VARIABLES.buscaNoticiasPayload.pagination.total_items)>
                <cfset VARIABLES.buscaNoticiasTotal = int(VARIABLES.buscaNoticiasPayload.pagination.total_items)>
            <cfelseif structKeyExists(VARIABLES.buscaNoticiasPayload.pagination, "total_count") AND isNumeric(VARIABLES.buscaNoticiasPayload.pagination.total_count)>
                <cfset VARIABLES.buscaNoticiasTotal = int(VARIABLES.buscaNoticiasPayload.pagination.total_count)>
            <cfelseif structKeyExists(VARIABLES.buscaNoticiasPayload.pagination, "total") AND isNumeric(VARIABLES.buscaNoticiasPayload.pagination.total)>
                <cfset VARIABLES.buscaNoticiasTotal = int(VARIABLES.buscaNoticiasPayload.pagination.total)>
            </cfif>
        </cfif>
        <cfif VARIABLES.buscaNoticiasTotal LTE 0>
            <cfset VARIABLES.buscaNoticiasTotal = arrayLen(VARIABLES.buscaNoticiasItens)>
        </cfif>
    <cfcatch>
        <cfset VARIABLES.buscaNoticiasItens = []>
        <cfset VARIABLES.buscaNoticiasTotal = 0>
        <cfset VARIABLES.buscaNoticiasErro = cfcatch.message>
    </cfcatch>
    </cftry>
</cfif>

<!--- REGISTRA A EXECUCAO DA ABA DE NOTICIAS PARA ANALISE AGREGADA DA BUSCA --->
<cfscript>
searchLogRepository = createObject("component", "repositories.SearchLogRepository").init("runnerhub");
searchLogRepository.write({
    "parentId" = isNumeric(URL.busca_log_id) ? val(URL.busca_log_id) : 0,
    "origin" = "api/noticias_busca.cfm",
    "stage" = "execucao",
    "searchTerm" = VARIABLES.buscaNoticiasTermo,
    "searchMode" = "conteudo",
    "searchType" = "noticias",
    "searchScope" = lCase(trim(URL.busca_tipo)),
    "error" = VARIABLES.buscaNoticiasErro,
    "counts" = {
        "noticias" = VARIABLES.buscaNoticiasTotal
    },
    "request" = {
        "method" = CGI.REQUEST_METHOD,
        "path" = CGI.SCRIPT_NAME,
        "url" = duplicate(URL)
    },
    "payload" = {
        "itemsReturned" = arrayLen(VARIABLES.buscaNoticiasItens),
        "perPage" = VARIABLES.buscaNoticiasPerPage
    }
});
</cfscript>

<!--- RENDERIZA CARDS DE NOTICIAS OU A MENSAGEM SEM RESULTADOS --->
<cfif arrayLen(VARIABLES.buscaNoticiasItens)>
    <div data-busca-total="<cfoutput>#VARIABLES.buscaNoticiasTotal#</cfoutput>">
        <div class="row g-2">
            <cfoutput>
                <cfloop array="#VARIABLES.buscaNoticiasItens#" index="item">
                    <cfset VARIABLES.imagemNoticia = structKeyExists(item, "featured_media") AND isStruct(item.featured_media) AND structKeyExists(item.featured_media, "url") ? trim(item.featured_media.url) : "">
                    <cfif len(trim(VARIABLES.imagemNoticia)) AND left(VARIABLES.imagemNoticia, 1) EQ "/">
                        <cfset VARIABLES.imagemNoticia = VARIABLES.apiConteudoBase & VARIABLES.imagemNoticia>
                    </cfif>
                    <cfset VARIABLES.logoCanalNoticia = "">
                    <cfif len(trim(item.slug)) AND structKeyExists(REQUEST, "i18nBuildPath")>
                        <cfset VARIABLES.apiNewsCurrentRouteParams = structKeyExists(REQUEST, "currentRouteParams") AND isStruct(REQUEST.currentRouteParams) ? duplicate(REQUEST.currentRouteParams) : {} />
                        <cfset VARIABLES.apiNewsRouteParams = duplicate(VARIABLES.apiNewsCurrentRouteParams) />
                        <cfset VARIABLES.apiNewsRouteParams["tag"] = trim(item.slug) />
                        <cfset REQUEST.currentRouteParams = VARIABLES.apiNewsRouteParams />
                        <cfset VARIABLES.apiNewsPath = REQUEST.i18nBuildPath("newsDetail") />
                        <cfset REQUEST.currentRouteParams = VARIABLES.apiNewsCurrentRouteParams />
                    <cfelse>
                        <cfset VARIABLES.apiNewsPath = "/noticias/#item.slug#/" />
                    </cfif>
                    <cfset VARIABLES.canalNoticia = structKeyExists(item, "content_type") AND isStruct(item.content_type) AND structKeyExists(item.content_type, "name") ? trim(item.content_type.name) : "">
                    <cfif structKeyExists(item, "content_type") AND isStruct(item.content_type) AND structKeyExists(item.content_type, "logo_url") AND len(trim(item.content_type.logo_url))>
                        <cfset VARIABLES.logoCanalNoticia = trim(item.content_type.logo_url)>
                    <cfelseif structKeyExists(item, "channel") AND isStruct(item.channel) AND structKeyExists(item.channel, "logo_url") AND len(trim(item.channel.logo_url))>
                        <cfset VARIABLES.logoCanalNoticia = trim(item.channel.logo_url)>
                    </cfif>
                    <cfif len(trim(VARIABLES.logoCanalNoticia)) AND left(VARIABLES.logoCanalNoticia, 1) EQ "/">
                        <cfset VARIABLES.logoCanalNoticia = VARIABLES.apiConteudoBase & VARIABLES.logoCanalNoticia>
                    </cfif>
                    <cfset VARIABLES.resumoNoticia = structKeyExists(item, "excerpt") ? trim(item.excerpt) : "">
                    <div class="col-12">
                        <a href="#VARIABLES.apiNewsPath#" class="text-decoration-none text-reset" data-audience-content-type="news" data-audience-content-id="#HTMLEditFormat(structKeyExists(item, "id") AND isSimpleValue(item.id) AND len(trim(item.id & "")) ? trim(item.id & "") : item.slug)#">
                            <div class="home-shell-card p-2">
                                <div class="row g-2 align-items-center">
                                    <div class="col-4 col-md-3">
                                        <div class="ratio ratio-16x9 rounded-1 overflow-hidden bg-light">
                                            <cfif len(trim(VARIABLES.imagemNoticia))>
                                                <img src="#VARIABLES.imagemNoticia#" alt="#HTMLEditFormat(item.title)#" class="w-100 h-100" style="object-fit: cover;" />
                                            <cfelse>
                                                <div class="w-100 h-100 d-flex align-items-center justify-content-center text-muted">
                                                    <cfif len(trim(VARIABLES.logoCanalNoticia))>
                                                        <img src="#HTMLEditFormat(VARIABLES.logoCanalNoticia)#" alt="#HTMLEditFormat(len(trim(VARIABLES.canalNoticia)) ? VARIABLES.canalNoticia : "Road Runners Press")#" loading="lazy" style="max-width:64%; max-height:58%; object-fit:contain;" onerror="this.onerror=null; this.style.display='none'; this.nextElementSibling.style.display='inline-flex';" />
                                                        <i class="fa-solid fa-newspaper" style="display:none;"></i>
                                                    <cfelse>
                                                        <i class="fa-solid fa-newspaper"></i>
                                                    </cfif>
                                                </div>
                                            </cfif>
                                        </div>
                                    </div>
                                    <div class="col-8 col-md-9 min-w-0">
                                        <cfif len(trim(VARIABLES.canalNoticia))><div class="small text-muted mb-1">#HTMLEditFormat(VARIABLES.canalNoticia)#</div></cfif>
                                        <h6 class="mb-1">#item.title#</h6>
                                        <cfif len(trim(VARIABLES.resumoNoticia))>
                                            <div class="small text-muted">#left(VARIABLES.resumoNoticia, 180)#<cfif len(VARIABLES.resumoNoticia) GT 180>...</cfif></div>
                                        </cfif>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </cfloop>
            </cfoutput>
        </div>
    </div>
<cfelse>
    <div class="home-feedback-card p-3" data-busca-total="0"><cfoutput>#HTMLEditFormat(len(trim(VARIABLES.buscaNoticiasTermoDisplay)) ? REQUEST.t("search.sections.noNewsForTerm", { "term" = VARIABLES.buscaNoticiasTermoDisplay }) : REQUEST.t("search.sections.noNews"))#</cfoutput></div>
</cfif>
