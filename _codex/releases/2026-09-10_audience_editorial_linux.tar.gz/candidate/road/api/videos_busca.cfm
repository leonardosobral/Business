<cfprocessingdirective pageencoding="utf-8"/>

<!--- NORMALIZA PARAMETROS DA BUSCA DE VIDEOS --->
<cfparam name="URL.busca" default=""/>
<cfparam name="URL.termo" default=""/>
<cfparam name="URL.busca_tipo" default="videos"/>
<cfparam name="URL.i18n_lang" default=""/>
<cfparam name="URL.busca_log_id" default=""/>

<!--- CARREGA TRADUCOES E ROTAS LOCALIZADAS --->
<cfinclude template="../includes/estrutura/variaveis.cfm"/>

<!--- DEFINE O TERMO USADO NA CONSULTA DE VIDEOS --->
<cfset VARIABLES.buscaVideosTermo = len(trim(URL.busca)) ? trim(URL.busca) : trim(URL.termo)/>
<cfscript>
// PREPARA O TERMO FORMATADO PARA A MENSAGEM DE ESTADO VAZIO
VARIABLES.buscaVideosTermoDisplay = "";
VARIABLES.buscaVideosTermoPalavras = [];
buscaVideosPalavra = "";

for (buscaVideosPalavra in listToArray(lCase(VARIABLES.buscaVideosTermo), " ")) {
    if (len(trim(buscaVideosPalavra))) {
        arrayAppend(
            VARIABLES.buscaVideosTermoPalavras,
            uCase(left(buscaVideosPalavra, 1)) & mid(buscaVideosPalavra, 2, len(buscaVideosPalavra))
        );
    }
}

VARIABLES.buscaVideosTermoDisplay = arrayToList(VARIABLES.buscaVideosTermoPalavras, " ");
</cfscript>
<cfset VARIABLES.buscaVideosLimite = lCase(trim(URL.busca_tipo)) EQ "videos" ? 40 : 12>

<!--- BUSCA VIDEOS PUBLICADOS PELO TERMO DIGITADO --->
<cfquery name="qBuscaVideos" result="qBuscaVideosMeta">
    SELECT media.id_media,
           media.media_titulo,
           media.media_url,
           media.data_publicacao,
           media.media_canal_nome AS nome_canal_video
    FROM tb_media media
    WHERE media.pub_status = TRUE
    <cfif len(trim(VARIABLES.buscaVideosTermo))>
        AND (
            unaccent(lower(media.media_titulo)) LIKE unaccent(lower(<cfqueryparam cfsqltype="cf_sql_varchar" value="%#VARIABLES.buscaVideosTermo#%"/>))
            OR unaccent(lower(coalesce(media.media_canal_nome, ''))) LIKE unaccent(lower(<cfqueryparam cfsqltype="cf_sql_varchar" value="%#VARIABLES.buscaVideosTermo#%"/>))
        )
    <cfelse>
        AND 1 = 0
    </cfif>
    ORDER BY media.data_publicacao DESC NULLS LAST,
             media.id_media DESC
    LIMIT <cfqueryparam cfsqltype="cf_sql_integer" value="#VARIABLES.buscaVideosLimite#"/>
</cfquery>
<cfset logQueryDebug("qBuscaVideos", qBuscaVideosMeta, "api_videos_busca/lista", "sem cache", qBuscaVideos)/>

<!--- CONTA O TOTAL DE VIDEOS COMPATIVEIS PARA OS BADGES DA BUSCA --->
<cfquery name="qBuscaVideosCount" result="qBuscaVideosCountMeta">
    SELECT count(*) AS total
    FROM tb_media media
    WHERE media.pub_status = TRUE
    <cfif len(trim(VARIABLES.buscaVideosTermo))>
        AND (
            unaccent(lower(media.media_titulo)) LIKE unaccent(lower(<cfqueryparam cfsqltype="cf_sql_varchar" value="%#VARIABLES.buscaVideosTermo#%"/>))
            OR unaccent(lower(coalesce(media.media_canal_nome, ''))) LIKE unaccent(lower(<cfqueryparam cfsqltype="cf_sql_varchar" value="%#VARIABLES.buscaVideosTermo#%"/>))
        )
    <cfelse>
        AND 1 = 0
    </cfif>
</cfquery>
<cfset logQueryDebug("qBuscaVideosCount", qBuscaVideosCountMeta, "api_videos_busca/count", "sem cache", qBuscaVideosCount)/>

<!--- REGISTRA A EXECUCAO DA ABA DE VIDEOS PARA ANALISE AGREGADA DA BUSCA --->
<cfscript>
searchLogRepository = createObject("component", "repositories.SearchLogRepository").init("runnerhub");
searchLogRepository.write({
    "parentId" = isNumeric(URL.busca_log_id) ? val(URL.busca_log_id) : 0,
    "origin" = "api/videos_busca.cfm",
    "stage" = "execucao",
    "searchTerm" = VARIABLES.buscaVideosTermo,
    "searchMode" = "conteudo",
    "searchType" = "videos",
    "searchScope" = lCase(trim(URL.busca_tipo)),
    "counts" = {
        "videos" = val(qBuscaVideosCount.total)
    },
    "request" = {
        "method" = CGI.REQUEST_METHOD,
        "path" = CGI.SCRIPT_NAME,
        "url" = duplicate(URL)
    },
    "payload" = {
        "itemsReturned" = qBuscaVideos.recordCount,
        "limit" = VARIABLES.buscaVideosLimite,
        "queryDebug" = structKeyExists(REQUEST, "queryDebug") ? REQUEST.queryDebug : []
    }
});
</cfscript>

<!--- RENDERIZA CARDS DE VIDEOS OU A MENSAGEM SEM RESULTADOS --->
<cfif qBuscaVideos.recordcount>
    <div data-busca-total="<cfoutput>#val(qBuscaVideosCount.total)#</cfoutput>">
        <div class="row g-2">
            <cfoutput query="qBuscaVideos">
                <cfset VARIABLES.videoTitleJs = HTMLEditFormat(JSStringFormat(media_titulo))>
                <div class="col-12">
                    <a href="##" class="text-decoration-none text-reset" data-audience-content-type="video" data-audience-content-id="#HTMLEditFormat(media_url)#" onclick="changeVideo('#HTMLEditFormat(media_url)#','#VARIABLES.videoTitleJs#'); return false;">
                        <div class="home-shell-card p-2">
                            <div class="row g-2 align-items-center">
                                <div class="col-4 col-md-3">
                                    <div class="ratio ratio-16x9 rounded-1 overflow-hidden bg-light">
                                        <img src="https://img.youtube.com/vi/#HTMLEditFormat(media_url)#/sddefault.jpg" alt="#HTMLEditFormat(media_titulo)#" class="w-100 h-100" style="object-fit: cover;" />
                                    </div>
                                </div>
                                <div class="col-8 col-md-9 min-w-0">
                                    <cfif len(trim(nome_canal_video))>
                                        <div class="small text-muted mb-1">#nome_canal_video#</div>
                                    </cfif>
                                    <h6 class="mb-1">#media_titulo#</h6>
                                    <cfif isDate(data_publicacao)>
                                        <div class="small text-muted">#lsDateFormat(data_publicacao, "dd/mm/yyyy")#</div>
                                    </cfif>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </cfoutput>
        </div>
    </div>
<cfelse>
    <div class="home-feedback-card p-3" data-busca-total="0"><cfoutput>#HTMLEditFormat(len(trim(VARIABLES.buscaVideosTermoDisplay)) ? REQUEST.t("search.sections.noVideosForTerm", { "term" = VARIABLES.buscaVideosTermoDisplay }) : REQUEST.t("search.sections.noVideos"))#</cfoutput></div>
</cfif>
