<div class="row">
    <div class="col-xs-12 mb-3">
        <cfset VARIABLES.badgeSize = 3/>
        <cfinclude template="/atleta/parts/badges.cfm"/>

        <cfif qPagina.perfil_publico OR (isDefined("qCheckSeguindo") AND qCheckSeguindo.recordcount)>
            <cfinclude template="/atleta/parts/tabela_melhores_marcas.cfm"/>
        </cfif>
    </div>
</div>

<div class="sticky"
     data-mdb-sticky-init
     data-mdb-sticky-boundary="true"
     data-mdb-sticky-direction="both"
     data-mdb-sticky-offset="64"
     data-mdb-sticky-delay="64">

    <cfif isDefined("qPerfil.strava_id")>
        <cfif len(trim(qPerfil.strava_id))>
            <a href="/maratonas/">
                <img src="/assets/banner_maratonas.jpg"
                     class="img-fluid rounded mb-2"
                     data-audience-slot="rr-profile-sidebar-promo"
                     data-audience-placement="rr-sidebar-static-promo"
                     data-audience-state="house"
                     alt="<cfoutput>#VARIABLES.activitySidebarCatalog.marathonsBrazilAlt#</cfoutput>"/>
            </a>
        <cfelse>
            <cfset VARIABLES.profileStravaOriginalRouteParams = structKeyExists(REQUEST, "currentRouteParams") AND isStruct(REQUEST.currentRouteParams) ? duplicate(REQUEST.currentRouteParams) : structNew()/>
            <cfset VARIABLES.profileStravaRouteParams = duplicate(VARIABLES.profileStravaOriginalRouteParams)/>
            <cfset VARIABLES.profileStravaRouteParams["tag"] = trim(qPerfil.tag)/>
            <cfset REQUEST.currentRouteParams = VARIABLES.profileStravaRouteParams/>
            <cfset VARIABLES.profileStravaRedirectPath = REQUEST.i18nBuildPath("athlete")/>
            <cfset VARIABLES.profileStravaRedirectUrl = "#APPLICATION.baseCanonica##VARIABLES.profileStravaRedirectPath#"/>
            <cfset REQUEST.currentRouteParams = VARIABLES.profileStravaOriginalRouteParams/>
            <a href="https://www.strava.com/oauth/authorize?client_id=110999&response_type=code&redirect_uri=<cfoutput>#VARIABLES.profileStravaRedirectUrl#</cfoutput>&approval_prompt=force&scope=read,activity:read,profile:read_all">
                <img src="/assets/banner_strava.jpg"
                     class="img-fluid rounded-5 shadow-3 mb-3"
                     data-audience-slot="rr-profile-sidebar-promo"
                     data-audience-placement="rr-sidebar-static-promo"
                     data-audience-state="house"
                     alt="<cfoutput>#REQUEST.t('common.activitySidebar.stravaConnectAlt')#</cfoutput>"/>
            </a>
        </cfif>
    </cfif>

    <cfinclude template="/includes/estrutura/side_footer.cfm"/>
</div>
