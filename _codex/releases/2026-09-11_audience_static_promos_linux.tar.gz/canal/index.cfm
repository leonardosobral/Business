<!doctype html>
<html lang="pt-br">

<cfprocessingdirective pageencoding="utf-8"/>

<!--- TEMPLATE --->
<cfset VARIABLES.template = "/canal/"/>

<!--- TAG PARAM TREAT --->
<cfparam name="URL.tag" default=""/>
<cfset URL.tag = trim(replace(URL.tag, '/', ''))/>

<!--- BACKEND --->
<cfinclude template="../includes/estrutura/variaveis.cfm"/>
<cfinclude template="../includes/backend/backend_perfil_edicao.cfm"/>
<cfinclude template="../includes/backend/backend.cfm"/>
<cfinclude template="../includes/backend/backend_login.cfm"/>
<cfinclude template="../includes/backend/backend_perfil_publico.cfm"/>
<cfinclude template="../includes/backend/backend_canal.cfm"/>

<!--- META INFO --->
<cfset VARIABLES.canonical = "#APPLICATION.baseCanonica##VARIABLES.template##URL.tag##Len(trim(URL.tag)) ? '/' : ''##VARIABLES.queryString#"/>
<cfset VARIABLES.title = "#qPagina.nome# - #APPLICATION.nomeSite#"/>
<cfset VARIABLES.description = "Canal #qPagina.nome# no #APPLICATION.nomeSite#"/>
<cfset VARIABLES.keywords = "resultado, provas, corrida, competição, pódio,atleta, corredor"/>

<!--- HEAD --->
<cfinclude template="../includes/estrutura/head.cfm"/>

<cfif Usuario.logado AND URL.tag EQ "">
    <cfoutput><meta http-equiv="refresh" content="0; url=#VARIABLES.template##qPagina.tag#/" /></cfoutput>
    <style>div{display: none !important;}</style>
</cfif>

<style>
    .sticky-offset {
        top: 56px;
    }
    .overlay {
        _opacity: 0;
        width: 180px;
        height: 180px;
        transition: .5s ease;
        opacity: 0;
        position: absolute;
        margin-left: -185px;
        margin-top: 10px;
    }
    .avatar:hover .overlay {
        opacity: 0.75;
    }
    .avatar:hover .photo {
        opacity: 0.75;
        transition: .5s ease;
    }
</style>

<body>

    <!--- SEO WEB TOOLS --->

    <cfinclude template="../includes/estrutura/seo-web-tools-body-start.cfm"/>


    <!--- CONTAINER DE CONTEUDO --->

    <div class="container">


        <!--- HEADER --->

        <cfinclude template="../includes/estrutura/header.cfm"/>
        <cfinclude template="../includes/estrutura/home_hero_busca.cfm"/>

        <main id="rr-page-content" class="rr-page-content" data-rr-page-content>

        <!--- CONTEUDO --->

        <div class="row g-2">

            <!--- MINI PERFIL --->

            <div class="col-md-3 d-none d-md-block">

                <cfset VARIABLES.homeSidebarAsyncFooter = "0"/>
                <cfinclude template="../includes/estrutura/home_sidebar_async_slot.cfm"/>

            </div>

            <!--- PERFIL --->

            <div class="col-12 col-md-6 px-lg-5">


                <!--- HEADER DA PAGINA --->

                <!---<div class="row">

                    <div class="col-3 col-md-2 col-lg-3 col-xl-2">
                    </div>

                    <div class="col-9 col-md-7 col-lg-6 col-xl-7 pe-0">
                        <div class="h5 ps-1 mb-0 lh-1"><cfoutput><span class="text-truncate d-inline-block" style="max-width: calc(100% - 30px)">#qPagina.nome#</span></cfoutput>
                            <cfif qPagina.verificado>
                                <img src="/assets/verified.png" data-mdb-acao="selo_verificado" class="align-top" alt="Atleta verificado" title="Atleta verificado"/>
                            <cfelseif Usuario.logado AND qPagina.id_usuario_cadastro EQ Usuario.id>
                                <img src="/assets/verified_not.png" class="align-top" style="cursor: pointer" title="Verificar Perfil do Atleta"/>
                            </cfif>
                        </div>
                        <div class="small ps-1"><cfif len(trim(qPagina.cidade))><i class="fa-solid fa-location-dot"></i>&nbsp;<cfoutput>#qPagina.cidade# - #qPagina.uf#</cfoutput></cfif>&nbsp;</div>
                            <div class="d-none d-md-flex ps-1 pb-2 small" style="max-height: 20px; min-height: 20px; line-height: 1rem; overflow:hidden"><cfif len(trim(qPagina.descricao))><cfoutput>#qPagina.descricao#</cfoutput></cfif>&nbsp;</div>
                    </div>

                    <div class="col-3 d-none d-md-block">

                        <cfif Usuario.logado>
                            <div class="justify-content-end d-flex flex-fill h-50 pb-2"><cfinclude template="parts/botao_seguir.cfm"/></div>
                        <cfelse>
                            <div class="justify-content-end d-flex flex-fill">
                                <button class="btn btn-sm shadow-0 btn-primary" data-mdb-modal-init data-mdb-target="#modalLogin" data-mdb-acao="perfil">Seguir</button>
                            </div>
                        </cfif>

                        <div class="text-end d-none d-md-block">
                        <cfif qPagina.perfil_publico OR qCheckSeguindo.recordcount>
                            <cfif len(trim(qPagina.strava_id)) AND Usuario.logado>
                                <a style="color: #666;" href="https://www.strava.com/athletes/<cfoutput>#qPagina.strava_id#</cfoutput>" role="button" target="_blank"><i class="fa-brands fa-strava fa-lg px-1"></i></a>
                            </cfif>
                            <cfif len(trim(qPagina.instagram)) AND qPagina.instagram_publico AND Usuario.logado>
                                <a style="color: #666;" href="https://instagram.com/<cfoutput>#qPagina.instagram#</cfoutput>" role="button" target="_blank"><i class="fa-brands fa-instagram fa-lg px-1"></i></a>
                            </cfif>
                            <cfif len(trim(qPagina.youtube)) AND qPagina.youtube_publico AND Usuario.logado>
                                <a style="color: #666;" href="https://youtube.com/<cfoutput>#qPagina.youtube#</cfoutput>" role="button" target="_blank"><i class="fa-brands fa-youtube fa-lg px-1"></i></a>
                            </cfif>
                            <cfif len(trim(qPagina.tiktok)) AND qPagina.tiktok_publico AND Usuario.logado>
                                <a style="color: #666;" href="https://tiktok.com/<cfoutput>#qPagina.youtube#</cfoutput>" role="button" target="_blank"><i class="fa-brands fa-tiktok fa-lg px-1"></i></a>
                            </cfif>
                            <cfif len(trim(qPagina.website)) AND qPagina.website_publico AND Usuario.logado>
                                <a style="color: #666;" href="<cfoutput>#qPagina.website#</cfoutput>" role="button" target="_blank"><i class="fa-solid fa-globe fa-lg px-1"></i></a>
                            </cfif>
                            <cfif len(trim(qPagina.whatsapp)) AND qPagina.whatsapp_publico AND Usuario.logado>
                                <a style="color: #666;" href="https://wa.me/<cfoutput>#qPagina.whatsapp#</cfoutput>" role="button" target="_blank"><i class="fa-brands fa-whatsapp fa-lg px-1"></i></a>
                            </cfif>
                        </cfif>
                        </div>

                    </div>

                </div>--->


                <!--- CONTEUDO DA PAGINA --->

                <div class="row m-auto">


                    <!--- BARRA DE BOTOES EDITAR/SEGUIR --->

                    <!---<div class="card pb-1 mb-2 pt-md-2">

                        <div class="row">

                                <div class="col-3 col-md-2 col-lg-3 col-xl-2 ps-2 pe-0">
                                    <cfif qPagina.recordCount>
                                        <cfoutput>
                                                <img src="#qPagina.imagem_usuario#" class="d-block d-md-none rounded-circle bg-light w-100 position-relative" style="margin-top:-50px;border: 5px solid rgba(235, 235, 235, 1);" alt="imagem do atleta" onerror="this.src='/assets/user.png';"/>
                                                <img src="#qPagina.imagem_usuario#" class="d-none d-md-block d-lg-none rounded-circle bg-light w-100 position-relative" style="margin-top:-80px;border: 5px solid rgba(235, 235, 235, 1);" alt="imagem do atleta" onerror="this.src='/assets/user.png';"/>
                                                <img src="#qPagina.imagem_usuario#" class="d-none d-lg-block rounded-circle bg-light w-100 position-relative" style="margin-top:-80px;border: 5px solid rgba(235, 235, 235, 1);" alt="imagem do atleta" onerror="this.src='/assets/user.png';"/>
                                        </cfoutput>
                                    </cfif>
                                </div>
                                <div class="col-9 d-md-none">
                                    <span class="d-block small"><cfoutput>#qPagina.descricao#</cfoutput></span>
                                    <cfif len(trim(qPagina.strava_id))>
                                            <a style="color: #666;" href="https://www.strava.com/athletes/<cfoutput>#qPagina.strava_id#</cfoutput>" role="button" target="_blank"><i class="fa-brands fa-strava fa-lg px-1"></i></a>
                                    </cfif>
                                    <cfif len(trim(qPagina.instagram))>
                                            <a style="color: #666;" href="https://instagram.com/<cfoutput>#qPagina.instagram#</cfoutput>" role="button" target="_blank"><i class="fa-brands fa-instagram fa-lg px-1"></i></a>
                                    </cfif>
                                    <cfif len(trim(qPagina.youtube))>
                                            <a style="color: #666;" href="https://youtube.com/<cfoutput>#qPagina.youtube#</cfoutput>" role="button" target="_blank"><i class="fa-brands fa-youtube fa-lg px-1"></i></a>
                                    </cfif>
                                    <cfif len(trim(qPagina.tiktok))>
                                            <a style="color: #666;" href="https://tiktok.com/<cfoutput>#qPagina.youtube#</cfoutput>" role="button" target="_blank"><i class="fa-brands fa-tiktok fa-lg px-1"></i></a>
                                    </cfif>
                                    <cfif len(trim(qPagina.website))>
                                            <a style="color: #666;" href="<cfoutput>#qPagina.website#</cfoutput>" role="button" target="_blank"><i class="fa-solid fa-globe fa-lg px-1"></i></a>
                                    </cfif>
                                    <cfif len(trim(qPagina.whatsapp))>
                                        <cfif qPagina.whatsapp_publico>
                                                <a style="color: #666;" href="https://wa.me/<cfoutput>#qPagina.whatsapp#</cfoutput>" role="button" target="_blank"><i class="fa-brands fa-whatsapp fa-lg px-1"></i></a>
                                        </cfif>
                                    </cfif>
                                </div>

                                <div class="pt-1 px-1 d-flex d-md-none justify-content-center">
                                    <cfinclude template="parts/botao_seguir.cfm"/>
                                </div>

                                <div class="col-12 col-md-10 col-lg-9 col-xl-10 pt-1 px-1 fs-4 small justify-content-center justify-content-md-start d-flex d-md-block gap-1">
                                    <cfif Usuario.logado>
                                        <cfif qPagina.perfil_publico OR qCheckSeguindo.recordcount>
                                            <cfif qPagina.id_usuario_cadastro EQ Usuario.id>
                                                <button class="btn btn-sm btn-secondary flex-fill px-1" onclick="window.location.href='/resultados/';"><cfoutput>#qCorridasAtleta.recordcount#</cfoutput> resultados</button>
                                            <cfelse>
                                                <button class="btn btn-sm btn-secondary flex-fill px-1" onclick="document.getElementById('tab-resultados').click();window.location.href='./?filtro=resultados';return false;"><cfoutput>#qCorridasAtleta.recordcount#</cfoutput> resultados</button>
                                            </cfif>
                                            <button class="btn btn-sm btn-secondary flex-fill px-1"
                                                    data-mdb-ripple-init
                                                    data-mdb-modal-init
                                                    data-mdb-target="#modal_seguidores"
                                                    data-mdb-tipo="Seguidores"
                                                    data-mdb-countseguindo="<cfoutput>#qSeguidores.recordcount#</cfoutput>"
                                                    data-mdb-countseguidores="<cfoutput>#qSeguindo.recordcount#</cfoutput>"
                                                    data-mdb-escopo="pagina"><cfoutput>#qSeguidores.recordcount#</cfoutput> seguidores</button>
                                            <button class="btn btn-sm btn-secondary flex-fill px-1"
                                                    data-mdb-ripple-init
                                                    data-mdb-modal-init
                                                    data-mdb-target="#modal_seguidores"
                                                    data-mdb-tipo="Seguindo"
                                                    data-mdb-countseguindo="<cfoutput>#qSeguidores.recordcount#</cfoutput>"
                                                    data-mdb-countseguidores="<cfoutput>#qSeguindo.recordcount#</cfoutput>"
                                                    data-mdb-escopo="pagina"><cfoutput>#qSeguindo.recordcount#</cfoutput> seguindo</button>
                                        <cfelse>
                                            <button class="btn btn-sm btn-secondary flex-fill px-1"><cfoutput>#qCorridasAtleta.recordcount#</cfoutput> resultados</button>
                                            <button class="btn btn-sm btn-secondary flex-fill px-1"><cfoutput>#qSeguidores.recordcount#</cfoutput> seguidores</button>
                                            <button class="btn btn-sm btn-secondary flex-fill px-1"><cfoutput>#qSeguindo.recordcount#</cfoutput> seguindo</button>
                                        </cfif>
                                    <cfelse>
                                        <button class="btn btn-sm btn-secondary flex-fill px-1" data-mdb-modal-init data-mdb-target="#modalLogin" data-mdb-acao="perfil"><cfoutput>#qCorridasAtleta.recordcount#</cfoutput> resultados</button>
                                        <button class="btn btn-sm btn-secondary flex-fill px-1" data-mdb-modal-init data-mdb-target="#modalLogin" data-mdb-acao="perfil"><cfoutput>#qSeguidores.recordcount#</cfoutput> seguidores</button>
                                        <button class="btn btn-sm btn-secondary flex-fill px-1" data-mdb-modal-init data-mdb-target="#modalLogin" data-mdb-acao="perfil"><cfoutput>#qSeguindo.recordcount#</cfoutput> seguindo</button>
                                    </cfif>
                                </div>

                        </div>

                    </div>--->

                    <div class="p-0">

                        <div class="row mb-1">

                            <div class="col ps-1 pe-0 z-3">
                                <div class="h5 ps-3 mb-0">

                                    <cfoutput>
                                        <a href="##" class="d-block float-start me-1 mt-n2 rounded-circle border border-4 border-white" data-mdb-modal-init data-mdb-target="##modalProfilePhoto">
                                            <img src="#qPagina.imagem_usuario#" class="rounded-circle bg-light border border-1 border-dark border-opacity-10" alt="imagem do atleta" onerror="this.src='/assets/user.png';" width="70" height="70"/>
                                            <!---<span class="position-absolute mt-5 ms-n3"><cfinclude template="../includes/verificado.cfm"/></span>--->
                                        </a>
                                        <h1 class="text-truncate d-inline-block h5 m-0" style="max-width: calc(100% - 110px)">#qPagina.nome#</h1>
                                    </cfoutput>
                                    <cfif qPagina.verificado OR qPagina.usuario_is_admin>
                                        <!---<img src="/assets/verified.png" width="19" data-mdb-acao="selo_verificado" class="align-bottom mb-2" alt="Atleta verificado" title="Atleta verificado"/>--->
                                        <!---<cfif qPagina.id_pagina EQ '95'>--->
                                                <!---<svg xmlns="http://www.w3.org/2000/svg" class="align-bottom mb-2" xmlns:xlink="http://www.w3.org/1999/xlink" width="19" zoomAndPan="magnify" viewBox="0 0 230.87999 231" height="19" preserveAspectRatio="xMidYMid meet" version="1.0"><defs><clipPath id="9d45e510e2"><path d="M 0 0.0585938 L 230.28125 0.0585938 L 230.28125 230.339844 L 0 230.339844 Z M 0 0.0585938 " clip-rule="nonzero"/></clipPath><clipPath id="d97adffae3"><path d="M 115.140625 0.0585938 C 51.550781 0.0585938 0 51.609375 0 115.199219 C 0 178.789062 51.550781 230.339844 115.140625 230.339844 C 178.730469 230.339844 230.28125 178.789062 230.28125 115.199219 C 230.28125 51.609375 178.730469 0.0585938 115.140625 0.0585938 Z M 115.140625 0.0585938 " clip-rule="nonzero"/></clipPath><clipPath id="29ad6322cf"><path d="M 0 0.0585938 L 230.28125 0.0585938 L 230.28125 230.339844 L 0 230.339844 Z M 0 0.0585938 " clip-rule="nonzero"/></clipPath><clipPath id="161ae007ec"><path d="M 115.140625 0.0585938 C 51.550781 0.0585938 0 51.609375 0 115.199219 C 0 178.789062 51.550781 230.339844 115.140625 230.339844 C 178.730469 230.339844 230.28125 178.789062 230.28125 115.199219 C 230.28125 51.609375 178.730469 0.0585938 115.140625 0.0585938 Z M 115.140625 0.0585938 " clip-rule="nonzero"/></clipPath><clipPath id="53b3ecc811"><rect x="0" width="231" y="0" height="231"/></clipPath><clipPath id="37ec83b390"><path d="M 0 0.0585938 L 230.128906 0.0585938 L 230.128906 230.191406 L 0 230.191406 Z M 0 0.0585938 " clip-rule="nonzero"/></clipPath><clipPath id="54d6872f10"><path d="M 115.136719 0.0585938 C 51.546875 0.0585938 0 51.609375 0 115.195312 C 0 178.78125 51.546875 230.332031 115.136719 230.332031 C 178.722656 230.332031 230.269531 178.78125 230.269531 115.195312 C 230.269531 51.609375 178.722656 0.0585938 115.136719 0.0585938 Z M 115.136719 0.0585938 " clip-rule="nonzero"/></clipPath><clipPath id="b274b6b155"><path d="M 36.632812 77.664062 L 193.300781 77.664062 L 193.300781 152.625 L 36.632812 152.625 Z M 36.632812 77.664062 " clip-rule="nonzero"/></clipPath></defs><g clip-path="url(#9d45e510e2)"><g clip-path="url(#d97adffae3)"><g transform="matrix(1, 0, 0, 1, 0, -0.000000000000038733)"><g clip-path="url(#53b3ecc811)"><g clip-path="url(#29ad6322cf)"><g clip-path="url(#161ae007ec)"><path fill="#f4b120" d="M 0 0.0585938 L 230.28125 0.0585938 L 230.28125 230.339844 L 0 230.339844 Z M 0 0.0585938 " fill-opacity="1" fill-rule="nonzero"/></g></g></g></g></g></g><g clip-path="url(#37ec83b390)"><g clip-path="url(#54d6872f10)"><path stroke-linecap="butt" transform="matrix(0.74961, 0, 0, 0.74961, -0.000000000000021305, 0.060015)" fill="none" stroke-linejoin="miter" d="M 153.595428 -0.00189598 C 68.764895 -0.00189598 0.000000000000028422 68.76821 0.000000000000028422 153.593532 C 0.000000000000028422 238.418854 68.764895 307.18896 153.595428 307.18896 C 238.42075 307.18896 307.185645 238.418854 307.185645 153.593532 C 307.185645 68.76821 238.42075 -0.00189598 153.595428 -0.00189598 Z M 153.595428 -0.00189598 " stroke="#ffffff" stroke-width="32" stroke-opacity="1" stroke-miterlimit="4"/></g></g><g clip-path="url(#b274b6b155)"><path fill="#ffffff" d="M 46.28125 77.664062 L 36.636719 77.664062 L 36.636719 152.730469 L 64.800781 152.730469 L 64.800781 143.730469 L 46.28125 143.730469 Z M 75.820312 152.730469 L 85.460938 152.730469 L 85.460938 77.664062 L 75.820312 77.664062 Z M 152.121094 118.101562 L 167.738281 118.101562 L 167.738281 109.105469 L 152.121094 109.105469 L 152.121094 86.660156 L 169.160156 86.660156 L 169.160156 77.664062 L 142.480469 77.664062 L 142.480469 152.730469 L 170.09375 152.730469 L 170.09375 143.730469 L 152.121094 143.730469 Z M 183.953125 152.730469 L 193.597656 152.730469 L 193.597656 143.730469 L 183.953125 143.730469 Z M 183.953125 77.664062 L 183.953125 134.730469 L 193.597656 134.730469 L 193.597656 77.664062 Z M 114.03125 128.253906 L 106.9375 77.664062 L 96.800781 77.664062 L 110.496094 152.726562 L 117.398438 152.726562 L 131.101562 77.664062 L 121.019531 77.664062 Z M 114.03125 128.253906 " fill-opacity="1" fill-rule="nonzero"/></g></svg>--->
                                        <!---<cfelse>--->
                                            <!---<svg xmlns="http://www.w3.org/2000/svg" class="align-bottom mb-2" data-mdb-acao="selo_verificado" alt="Atleta verificado" title="Atleta verificado" width="19" height="19" viewBox="0 0 24 24"><g fill="#ffffff" fill-rule="evenodd"><path fill="#fafafa" d="M23.7891059,9.7125 L20.7246059,7.14 L20.0286059,3.1995 C19.9791059,2.9175 19.7331059,2.7105 19.4466059,2.7105 L15.4461059,2.7105 L12.3801059,0.1395 C12.2706059,0.048 12.1341059,-8.8817842e-15 12.0006059,-8.8817842e-15 C11.8656059,-8.8817842e-15 11.7291059,0.048 11.6196059,0.1395 L8.55510593,2.7105 L4.55310593,2.7105 C4.26660593,2.7105 4.02060593,2.9175 3.97110593,3.1995 L3.27660593,7.14 L0.21060593,9.7125 C-0.00839406997,9.897 -0.06389407,10.212 0.07860593,10.461 L2.07960593,13.926 L1.38510593,17.8665 C1.33560593,18.1485 1.49610593,18.4275 1.76460593,18.525 L5.52510593,19.893 L7.52610593,23.3595 C7.63410593,23.547 7.83210593,23.655 8.03760593,23.655 C8.10510593,23.655 8.17410593,23.643 8.24010593,23.619 L12.0006059,22.2495 L15.7596059,23.619 C15.8256059,23.643 15.8946059,23.655 15.9621059,23.655 C16.1676059,23.655 16.3656059,23.547 16.4751059,23.3595 L18.4746059,19.893 L22.2351059,18.525 C22.5051059,18.4275 22.6641059,18.1485 22.6146059,17.8665 L21.9201059,13.926 L23.9211059,10.461 C24.0651059,10.212 24.0081059,9.897 23.7891059,9.7125"/><path fill="#F4B120" d="M22.1544059,10.0113 C22.3419059,10.1688 22.3899059,10.4403 22.2669059,10.6548 L20.5494059,13.6293 L21.1464059,17.0133 C21.1884059,17.2563 21.0519059,17.4948 20.8194059,17.5788 L17.5914059,18.7533 L15.8724059,21.7293 C15.7794059,21.8913 15.6099059,21.9828 15.4329059,21.9828 C15.3744059,21.9828 15.3159059,21.9753 15.2589059,21.9528 L12.0294059,20.7783 L8.80140593,21.9528 C8.74440593,21.9753 8.68590593,21.9828 8.62740593,21.9828 C8.45040593,21.9828 8.28090593,21.8913 8.18790593,21.7293 L6.46890593,18.7533 L3.24090593,17.5788 C3.00840593,17.4948 2.87190593,17.2563 2.91390593,17.0133 L3.51090593,13.6293 L1.79190593,10.6548 C1.66890593,10.4403 1.71690593,10.1688 1.90590593,10.0113 L4.53840593,7.8018 L5.13540593,4.4178 C5.17740593,4.1748 5.38890593,3.9978 5.63490593,3.9978 L9.07140593,3.9978 L11.7039059,1.7898 C11.7984059,1.7103 11.9139059,1.6698 12.0294059,1.6698 C12.1464059,1.6698 12.2619059,1.7103 12.3564059,1.7898 L14.9889059,3.9978 L18.4254059,3.9978 C18.6714059,3.9978 18.8814059,4.1748 18.9249059,4.4178 L19.5219059,7.8018 L22.1544059,10.0113 Z M16.0694457,8.70488982 L10.5499059,14.2244296 L8.09286611,11.7673898 C7.75847969,11.4330034 7.21633217,11.4330034 6.88194575,11.7673898 C6.54755932,12.1017762 6.54755932,12.6439238 6.88194575,12.9783102 L9.94444575,16.0408102 C10.2788322,16.3751966 10.8209797,16.3751966 11.1553661,16.0408102 L17.2803661,9.91581018 C17.6147525,9.58142376 17.6147525,9.03927624 17.2803661,8.70488982 C16.9459797,8.37050339 16.4038322,8.37050339 16.0694457,8.70488982 Z"/></g></svg>--->
                                            <cfset VARIABLES.verificadoBadgeIsAdmin = qPagina.usuario_is_admin/>
                                            <span class="d-inline-flex align-text-top"><cfinclude template="../includes/verificado.cfm"/></span>
                                        <!---</cfif>--->
                                    <cfelseif Usuario.logado AND qPagina.id_usuario_cadastro EQ Usuario.id>
                                    </cfif>
                                </div>

                                <div class="float-end pt-0 pe-3">
                                    <cfif Usuario.logado>
                                        <cfinclude template="parts/botao_seguir.cfm"/>
                                    <cfelse>
                                            <button type="button" alt="Seguir"
                                                    class="btn btn-sm shadow-0 btn-primary"
                                                    data-mdb-modal-init
                                                    data-mdb-target="#modalLogin"
                                                    data-mdb-acao="perfil">
                                                Seguir
                                            </button>
                                    </cfif>
                                </div>

                                <div class="">
                                    <cfif len(trim(qPagina.strava_id))>
                                            <a href="https://www.strava.com/athletes/<cfoutput>#qPagina.strava_id#</cfoutput>" role="button" target="_blank"><i class="fa-brands fa-strava me-1 fs-5 opacity-80"></i></a>
                                    </cfif>
                                    <cfif len(trim(qPagina.instagram))>
                                            <a href="https://instagram.com/<cfoutput>#qPagina.instagram#</cfoutput>" role="button" target="_blank"><i class="fa-brands fa-instagram me-1 fs-5 opacity-80"></i></a>
                                    </cfif>
                                    <cfif len(trim(qPagina.youtube))>
                                            <a href="https://youtube.com/<cfoutput>#qPagina.youtube#</cfoutput>" role="button" target="_blank"><i class="fa-brands fa-youtube me-1 fs-5 opacity-80"></i></a>
                                    </cfif>
                                    <cfif len(trim(qPagina.tiktok))>
                                            <a href="https://tiktok.com/<cfoutput>#qPagina.youtube#</cfoutput>" role="button" target="_blank"><i class="fa-brands fa-tiktok me-1 fs-5 opacity-80"></i></a>
                                    </cfif>
                                    <cfif len(trim(qPagina.website))>
                                            <a href="<cfoutput>#qPagina.website#</cfoutput>" role="button" target="_blank"><i class="fa-solid fa-globe me-1 fs-5 opacity-80"></i></a>
                                    </cfif>
                                    <cfif len(trim(qPagina.whatsapp))>
                                        <cfif qPagina.whatsapp_publico>
                                                <a href="https://wa.me/<cfoutput>#qPagina.whatsapp#</cfoutput>" role="button" target="_blank"><i class="fa-brands fa-whatsapp me-1 fs-5 opacity-80"></i></a>
                                        </cfif>
                                    </cfif>
                                </div>

                            </div>

                        </div>

                        <div class="mb-2 card card-principal mt-n5">

                            <div class="small mt-4 pt-1" style="margin-left:90px;">


                                <cfif len(trim(qPagina.cidade))>
                                    <small class="d-block"><i class="fa-solid fa-location-dot"></i>&nbsp;<cfoutput>#qPagina.cidade# - #qPagina.uf#</cfoutput></small>
                                </cfif>
                                <cfif len(trim(qPagina.descricao))>
                                    <small class="d-block"><i class="fa-solid fa-asterisk"></i>&nbsp;<cfoutput>#qPagina.descricao#</cfoutput></small>
                                </cfif>


                            </div>

                            <div class="d-flex justify-content-center small p-1">

                                <cfif Usuario.logado>

                                    <button data-mdb-modal-init
                                        data-mdb-target="#modal_seguidores"
                                        data-mdb-tipo="Seguidores"
                                        data-mdb-countseguindo="<cfoutput>#qSeguidores.recordcount#</cfoutput>"
                                        data-mdb-countseguidores="<cfoutput>#qSeguindo.recordcount#</cfoutput>"
                                        data-mdb-escopo="pagina"
                                        class="btn btn-sm btn-secondary px-1 mx-1 w-100">
                                        <div class="fs-5"><cfoutput>#qSeguidores.recordcount#</cfoutput></div><div class="small">seguidores</div>
                                    </button>

                                    <button data-mdb-modal-init
                                        data-mdb-target="#modal_seguidores"
                                        data-mdb-tipo="Seguindo"
                                        data-mdb-countseguindo="<cfoutput>#qSeguidores.recordcount#</cfoutput>"
                                        data-mdb-countseguidores="<cfoutput>#qSeguindo.recordcount#</cfoutput>"
                                        data-mdb-escopo="pagina"
                                        class="btn btn-sm btn-secondary px-1 w-100">
                                            <div class="fs-5"><cfoutput>#qSeguindo.recordcount#</cfoutput></div><div class="small">seguindo</div>
                                    </button>

                                <cfelse>

                                    <button data-mdb-modal-init
                                        data-mdb-target="#modalLogin"
                                        data-mdb-acao="perfil"
                                        class="btn btn-sm btn-secondary px-1 mx-1 w-100">
                                        <div class="fs-5"><cfoutput>#qSeguidores.recordcount#</cfoutput></div><div class="small">seguidores</div>
                                    </button>

                                    <button data-mdb-modal-init
                                        data-mdb-target="#modalLogin"
                                        data-mdb-acao="perfil"
                                        class="btn btn-sm btn-secondary px-1 w-100">
                                            <div class="fs-5"><cfoutput>#qSeguindo.recordcount#</cfoutput></div><div class="small">seguindo</div>
                                    </button>

                                </cfif>

                            </div>

                        </div>

                    </div>


                    <!--- ABAS DO PERFIL --->

                    <ul class="nav nav-tabs nav-justified my-2" id="ex1" role="tablist">

                        <li class="nav-item" role="presentation">
                            <a data-mdb-tab-init class="nav-link p-1 <cfif URL.filtro EQ "">active</cfif>" id="tab-atividades" href="#tabs-atividades"
                               role="tab" aria-controls="tabs-atividades" aria-selected="true" onclick="window.history.pushState('Object', 'Atividades', './');">
                                <i class="fa-solid fa-list fs-2"></i>
                                <div class="small py-2">Atividades</div>
                            </a>
                        </li>

                        <li class="nav-item" role="presentation">
                            <a data-mdb-tab-init class="nav-link p-1 <cfif URL.filtro EQ "agenda">active</cfif>" id="tab-agenda" href="#tabs-agenda"
                               role="tab" aria-controls="tabs-agenda" aria-selected="false" onclick="window.history.pushState('Object', 'Agenda', './?filtro=agenda');">
                                <i class="fa-solid fa-calendar fs-2"></i>
                                <div class="small py-2">Agenda</div>
                            </a>
                        </li>

                        <li class="nav-item" role="presentation">
                            <a data-mdb-tab-init class="nav-link p-1 <cfif URL.filtro EQ "cupons">active</cfif>" id="tab-cupons" href="#tabs-cupons"
                                role="tab" aria-controls="tabs-cupons" aria-selected="false" onclick="window.history.pushState('Object', 'Cupons', './?filtro=cupons');">
                                <i class="fa-solid fa-ticket fs-2"></i>
                                <span class="small py-2">Cupom</span>
                            </a>
                        </li>

                        <cfif Usuario.logado AND qPagina.id_usuario_cadastro EQ Usuario.id>
                            <li class="nav-item d-none" role="presentation">
                                <a data-mdb-tab-init class="nav-link p-1" id="tab-configuracoes" href="#tabs-configuracoes"
                                   role="tab" aria-controls="tabs-configuracoes" aria-selected="false" onclick="window.history.pushState('Object', 'Configurações', './?filtro=configuracoes');">
                                    <h6><i class="fa-solid fa-cog d-lg-none fs-2"></i><span class="d-none d-lg-inline small"><i class="fa-solid fa-cog d-block fs-2"></i>Minha Conta</span></h6>
                               </a>
                            </li>
                        </cfif>

                    </ul>


                    <!--- CONTEUDO DAS ABAS DO PERFIL --->

                    <div class="tab-content p-0" id="ex2-content">


                            <!--- SOCIAL --->

                            <div class="tab-pane fade <cfif URL.filtro EQ "">show active</cfif>" id="tabs-atividades" role="tabpanel" aria-labelledby="tab-atividades">

                                <!--- QUERY DO FEED --->
                                <cfinclude template="parts/area_social_backend.cfm"/>

                                <!--- POST FORM --->

                                <cfinclude template="parts/area_social_form.cfm"/>

                                <!--- ESCOLHA DO TIPO DE FEED --->

                                <!---<cfinclude template="area_social_filtros.cfm"/>--->

                                <!--- AVISO DO FEED --->

                                <cfinclude template="parts/area_social_aviso.cfm"/>

                                <!--- FEED --->

                                <cfinclude template="parts/area_social.cfm"/>

                            </div>


                            <!--- AGENDA --->

                            <div class="tab-pane fade <cfif URL.filtro EQ "agenda">show active</cfif>" id="tabs-agenda" role="tabpanel" aria-labelledby="tab-agenda">

                                <cfinclude template="parts/agenda.cfm"/>

                            </div>


                            <!--- CUPONS --->

                            <cfif qPagina.profissional>

                                <div class="tab-pane fade <cfif URL.filtro EQ "cupons">show active</cfif>" id="tabs-cupons" role="tabpanel" aria-labelledby="tab-cupons">

                                    <cfinclude template="parts/cupons.cfm"/>

                                </div>

                            </cfif>


                            <!--- CONFIGURACOES --->

                            <cfif Usuario.logado AND qPagina.id_usuario_cadastro EQ Usuario.id>

                                <div class="tab-pane fade <cfif URL.filtro EQ "configuracoes">show active</cfif>" id="tabs-configuracoes" role="tabpanel" aria-labelledby="tab-configuracoes">

                                    <cfinclude template="parts/configuracoes.cfm"/>

                                </div>

                            </cfif>


                        </div>

                </div>

            </div>

            <!--- BARRA LATERAL (DESKTOP) --->

            <div class="col-md-3 d-none d-md-block">

                <div class="row">

                    <div class="col-xs-12 mb-3">

                        <cfset VARIABLES.badgeSize = 3/>

                        <cfinclude template="parts/badges.cfm"/>

                        <!--- MELHORES MARCAS --->

                        <cfif qPagina.perfil_publico OR (isDefined("qCheckSeguind") AND qCheckSeguindo.recordcount)>

                            <cfinclude template="parts/tabela_melhores_marcas.cfm"/>

                        </cfif>

                    </div>

                </div>

                <div  class="sticky"
                      data-mdb-sticky-init
                      data-mdb-sticky-boundary="true"
                      data-mdb-sticky-direction="both"
                      data-mdb-sticky-offset="64"
                      data-mdb-sticky-delay="64">

                    <!--- RODAPE --->

                    <cfif isDefined("qMeuPerfil.strava_id")>
                        <cfif len(trim(qMeuPerfil.strava_id))>
                            <a href="/maratonas/">
                                <img src="/assets/banner_maratonas.jpg" class="img-fluid rounded mb-2" data-audience-slot="rr-channel-sidebar-promo" data-audience-placement="rr-sidebar-static-promo" data-audience-state="house" alt="Todas as Maratonas do Brasil"/>
                            </a>
                        <cfelse>
                            <a href="https://www.strava.com/oauth/authorize?client_id=110999&response_type=code&redirect_uri=<cfoutput>#APPLICATION.baseCanonica#/atleta/#qMeuPerfil.tag#</cfoutput>/&approval_prompt=force&scope=read,activity:read,profile:read_all">
                                <img src="/assets/banner_strava.jpg" class="img-fluid rounded-5 shadow-3 mb-3" data-audience-slot="rr-channel-sidebar-promo" data-audience-placement="rr-sidebar-static-promo" data-audience-state="house" alt="Conecte seu perfil ao Strava"/>
                            </a>
                        </cfif>
                    </cfif>

                    <cfinclude template="/includes/estrutura/side_footer.cfm"/>

                </div>

            </div>

        </div>

        </main>

    </div>



    <!--- FOOTER --->

    <cfinclude template="../includes/estrutura/footer.cfm"/>


    <!--- MODAL DE ENVIAR --->

    <cfinclude template="../includes/modal/modal_enviar.cfm"/>


    <!--- MODAL DA FOTO DO PERFIL --->

    <cfinclude template="../includes/modal/modal_profile_photo.cfm"/>


    <!--- MODAL DE BADGES --->

    <cfinclude template="../includes/modal/modal_badges.cfm"/>


    <!--- MODAL DE YOUTUBE --->

    <cfinclude template="../includes/modal/modal_youtube.cfm"/>


    <!--- MODAL FOCO --->

    <cfinclude template="../includes/modal/modal_cupom_foco.cfm"/>


    <!--- MODAL CADASTRO EVENTO --->

    <cfinclude template="../includes/modal/modal_cadastro_evento.cfm"/>


    <!--- MODAL LOGIN --->

    <cfinclude template="../includes/modal/modal_login.cfm"/>


    <!--- MODAL SEGUIDORES / SEGUINDO --->

    <cfinclude template="../includes/modal/modal_seguidores.cfm"/>


    <!--- MODAL PAGAMENTO --->

    <cfinclude template="../includes/modal/modal_pagamento.cfm"/>


    <!--- SEO WEB TOOLS --->

    <cfinclude template="../includes/estrutura/seo-web-tools-body-end.cfm"/>


</body>

</html>
