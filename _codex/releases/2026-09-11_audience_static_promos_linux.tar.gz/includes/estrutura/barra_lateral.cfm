<div class="rr-mobile-hide-sidebar">
<style>
    @media (max-width: 767.98px) {
        .rr-mobile-hide-sidebar {
            display: none !important;
        }
    }
</style>
<cfset appsMenuCatalog = REQUEST.i18n.common.appsMenu />
<cfset activitySidebarCatalog = REQUEST.i18n.common.activitySidebar />
<cfset VARIABLES.sidebarChallengesPath = structKeyExists(REQUEST, "i18nBuildPath") ? REQUEST.i18nBuildPath("challenges") : "/desafios/" />
<cfset VARIABLES.sidebarMarathonsPath = "/maratonas/" />
<!--- INICIO PROFILE --->
<div class="sticky"
     data-mdb-sticky-init data-mdb-sticky-boundary="true"
     data-mdb-sticky-direction="both"
     data-mdb-sticky-offset="64"
     data-mdb-sticky-delay="64">
    <!---<ul class="nav nav-tabs nav-justified d-none d-md-flex bg-light rounded mb-2" id="ex1" role="tablist">

    <li class="nav-item">
            <a class="nav-link p-2 <cfif VARIABLES.template EQ "/">active</cfif>" href="/">
        <i class="fa-solid fa-house fs-4"></i>
    </a>
    </li>

    <li class="nav-item">
            <a class="nav-link p-2 <cfif VARIABLES.template EQ "/calendario/">active</cfif>" href="/calendario/">
        <i class="fa-regular fa-calendar fs-4"></i>
    </a>
    </li>

    <li class="nav-item">
            <a class="nav-link p-2 <cfif VARIABLES.template EQ "/resultados/">active</cfif>" href="/resultados/">
        <i class="fa-solid fa-medal fs-4"></i>
    </a>
    </li>

    <li class="nav-item">
            <a class="nav-link p-2 <cfif VARIABLES.template EQ "/busca/">active</cfif>" href="/busca/">
        <i class="fa-solid fa-magnifying-glass fs-4"></i>
    </a>
    </li>

    </ul>--->
</div>

</div>

<div class="d-none d-lg-block">

    <!--- BANNERS: MARATONAS, STRAVA OU CRIAR PERFIL --->

    <!---<cfif isDefined("qPerfil.strava_id")>
        <cfif len(trim(qPerfil.strava_id))>
            <cfif qCheck365Inscrito.status EQ "C">
                <!---<div class="btn-group btn-group-sm d-flex mb-3" role="group" aria-label="Menu 365">
                    <button type="button" class="btn btn-secondary border border-2" style="border-color: #f37032 !important;" onclick="window.location.href='#VARIABLES.sidebarChallengesPath#';" data-mdb-ripple-init>Desafio 365 Corrida No Ar</button>
                </div>--->
            <cfelse>
                <!---<a href="/desafiocna/" target="_blank"><img src="/assets/banner_cna365.jpg" class="img-fluid rounded-5 shadow-3 mb-3" alt="Desafio 365"/></a>--->
            </cfif>
        <cfelse>
            <a href="https://www.strava.com/oauth/authorize?client_id=110999&response_type=code&redirect_uri=<cfoutput>#APPLICATION.baseCanonica#/atleta/#qPerfil.tag#</cfoutput>/&approval_prompt=force&scope=read,activity:read,profile:read_all"><img src="/assets/banner_strava.jpg" class="img-fluid rounded-5 shadow-3 mb-3" alt="Conecte seu perfil ao Strava"/></a>
        </cfif>
    </cfif>--->

    <cfset banner = RandRange(1, 2)>
    <cfif banner EQ 1>
        <a href="/circuitocatarinense/">
            <img src="/assets/banner_catarinense.jpg?2" class="img-fluid rounded mb-2" data-audience-slot="rr-legacy-sidebar-promo" data-audience-placement="rr-sidebar-static-promo" data-audience-state="house" alt="<cfoutput>#appsMenuCatalog.circuitoCatarinenseAlt#</cfoutput>"/>
        </a>
    <cfelseif banner EQ 2>
        <a href="/desafio/todosantodia/">
            <img src="/assets/banner_tsd.jpg" class="img-fluid rounded mb-2" data-audience-slot="rr-legacy-sidebar-promo" data-audience-placement="rr-sidebar-static-promo" data-audience-state="house" alt="<cfoutput>#appsMenuCatalog.todoSantoDiaAlt#</cfoutput>"/>
        </a>
    </cfif>

</div>

<!--- VIDEOS CORRIDA NO AR --->

<cfinclude template="videos_lateral.cfm"/>


<!--- NOTICIAS CORRIDA NO AR --->

<!---<cfinclude template="noticias_lateral.cfm"/>--->


<!--- OUTROS BANNERS STICKY ROLAGEM --->

<div class="sticky"
      data-mdb-sticky-init
     data-mdb-sticky-boundary="true"
      data-mdb-sticky-direction="both"
      data-mdb-sticky-offset="64"
      data-mdb-sticky-delay="64">

    <a href="#VARIABLES.sidebarMarathonsPath#">
        <img src="/assets/banner_maratonas.jpg" class="img-fluid rounded mb-2" data-audience-slot="rr-legacy-sidebar-marathons" data-audience-placement="rr-sidebar-static-promo" data-audience-state="house" alt="<cfoutput>#activitySidebarCatalog.marathonsBrazilAlt#</cfoutput>"/>
    </a>

    <!---<cfif isDefined("qPerfil.strava_id")>
        <cfif len(trim(qPerfil.strava_id))>
            <!---<a href="/maratonas/">
                <img src="/assets/banner_maratonas.jpg" class="img-fluid rounded mb-2" alt="Todas as Maratonas do Brasil"/>
            </a>--->
            <cfset banner = RandRange(1, 2)>
            <cfif banner EQ 1>
                <a href="/circuitocatarinense/">
                    <img src="/assets/banner_catarinense.jpg?2" class="img-fluid rounded mb-2" alt="Circuito Catarinense de Corrida"/>
                </a>
            <cfelseif banner EQ 2>
                <a href="/desafio/todosantodia/">
                    <img src="/assets/banner_tsd.jpg" class="img-fluid rounded mb-2" alt="Desafio Todo Santo Dia"/>
                </a>
            </cfif>
        <cfelse>
            <a href="https://www.strava.com/oauth/authorize?client_id=110999&response_type=code&redirect_uri=<cfoutput>#APPLICATION.baseCanonica#/atleta/#qPerfil.tag#</cfoutput>/&approval_prompt=force&scope=read,activity:read,profile:read_all">
                <img src="/assets/banner_strava.jpg" class="img-fluid rounded-5 shadow-3 mb-3" alt="Conecte seu perfil ao Strava"/>
            </a>
        </cfif>
    </cfif>--->

    <!--- BANNER SUGESTAO --->

    <!---<div data-bs-toggle="modal" data-bs-target="#modal_evento_cadastro" class="link">--->
        <!---<img src="/assets/banner_sugestao.jpg" class="img-fluid rounded-5 mb-3" alt="Não achou uma corrida?"/>--->
    <!---</div>--->

    <!--- RODAPE --->

    <cfinclude template="side_footer.cfm"/>

</div>
