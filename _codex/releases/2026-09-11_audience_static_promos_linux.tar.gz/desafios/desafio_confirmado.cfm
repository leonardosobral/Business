<cfinclude template="backend_desafio_confirmado.cfm"/>

<cfset appsMenuCatalog = REQUEST.i18n.common.appsMenu />
<cfset challengeDetailsCatalog = REQUEST.i18n.challenges.details />
<cfset challengeDetailPageCatalog = REQUEST.i18n.challenges.detailPage />
<cfset challengeJoinedDateLabel = REQUEST.t("challenges.detailPage.participatingSince", {"date" = dateFormat(qMeusDesafio.data_inscricao,"dd/mm/yyyy")}) />

<cfquery name="qResumoDesafioHomologado" dbtype="query">
    SELECT count(homologado) total, sum(distance) as distance from qStravaDiarioDesc
    WHERE homologado is not null
</cfquery>

<style>
    .challenge-detail-card,
    .challenge-stat-card,
    .challenge-support-card {
        border: 1px solid rgba(51, 51, 51, 0.08);
        border-radius: 10px;
        background-color: #ffffff;
        color: #333333;
        overflow: hidden;
        box-shadow: none;
    }

    .challenge-detail-media {
        display: block;
        width: 100%;
        background-color: #efefef;
    }

    .challenge-detail-body {
        padding: 1rem;
    }

    .challenge-kicker {
        color: rgba(51, 51, 51, 0.62);
        font-size: 0.68rem;
        font-weight: 800;
        letter-spacing: 0.08em;
        line-height: 1;
        text-transform: uppercase;
    }

    .challenge-title {
        color: #333333;
        font-size: 1.25rem;
        font-weight: 800;
        line-height: 1.15;
        margin: 0.25rem 0 0.4rem;
    }

    .challenge-copy {
        color: rgba(51, 51, 51, 0.72);
        font-size: 0.86rem;
        line-height: 1.4;
    }

    .challenge-badge-info {
        display: inline-flex;
        align-items: center;
        gap: 0.35rem;
        padding: 0.38rem 0.55rem;
        border-radius: 8px;
        background-color: #fab120;
        color: #333333;
        font-size: 0.72rem;
        font-weight: 800;
        line-height: 1;
    }

    .challenge-status-row {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 0.45rem;
        margin-top: 0.75rem;
    }

    .challenge-refresh-button {
        display: inline-flex;
        align-items: center;
        gap: 0.3rem;
        border: 1px solid rgba(51, 51, 51, 0.08);
        border-radius: 8px;
        background-color: #ffffff;
        color: #333333;
        font-size: 0.72rem;
        font-weight: 800;
        line-height: 1;
        padding: 0.38rem 0.55rem;
        box-shadow: none !important;
    }

    .challenge-refresh-button i {
        color: #fab120;
    }

    .challenge-refresh-button:disabled {
        opacity: 0.62;
        cursor: not-allowed;
    }

    .challenge-action-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 0.5rem;
        margin-top: 0.95rem;
    }

    .challenge-action-grid .btn {
        border-radius: 8px;
        box-shadow: none;
        font-size: 0.78rem;
        font-weight: 800;
        padding: 0.55rem 0.6rem;
    }

    .challenge-action-grid form {
        margin: 0;
    }

    .challenge-action-grid form .btn {
        width: 100%;
    }

    .challenge-stat-card {
        padding: 0.9rem;
        height: 100%;
    }

    .challenge-stat-icon {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 38px;
        height: 38px;
        border-radius: 10px;
        background-color: #efefef;
        color: #fab120;
        margin-bottom: 0.65rem;
    }

    .challenge-stat-label {
        color: rgba(51, 51, 51, 0.62);
        font-size: 0.68rem;
        font-weight: 800;
        letter-spacing: 0.06em;
        line-height: 1;
        text-transform: uppercase;
    }

    .challenge-stat-value {
        color: #333333;
        font-size: 1.08rem;
        font-weight: 800;
        line-height: 1.1;
        margin-top: 0.35rem;
    }

    .challenge-stat-caption {
        color: rgba(51, 51, 51, 0.62);
        font-size: 0.72rem;
        line-height: 1.25;
        margin-top: 0.3rem;
    }

    .challenge-section-card {
        border: 1px solid rgba(51, 51, 51, 0.08);
        border-radius: 10px;
        background-color: #ffffff;
        padding: 0.95rem;
        box-shadow: none;
    }

    .challenge-section-title {
        color: rgba(51, 51, 51, 0.76);
        font-size: 0.7rem;
        font-weight: 800;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        margin-bottom: 0.65rem;
    }

    .challenge-support-grid {
        display: grid;
        grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
        gap: 0.5rem;
    }

    .challenge-support-link {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.4rem;
        border: 1px solid rgba(51, 51, 51, 0.08);
        border-radius: 8px;
        background-color: #efefef;
        color: #333333;
        font-size: 0.78rem;
        font-weight: 800;
        padding: 0.65rem;
        text-decoration: none;
    }

    .challenge-support-link i {
        color: #fab120;
    }

    @media (max-width: 575.98px) {
        .challenge-action-grid,
        .challenge-support-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<!--- HEADER DO DESAFIO --->

<div class="challenge-detail-card mb-2">
    <img src="<cfoutput>#qDesafioSelecionado.imagem#</cfoutput>" class="challenge-detail-media" alt="<cfoutput>#qDesafioSelecionado.titulo#</cfoutput>">

    <div class="challenge-detail-body">
        <div class="challenge-kicker"><cfoutput>#challengeDetailPageCatalog.activeKicker#</cfoutput></div>
        <h1 class="challenge-title">
            <cfoutput>#qDesafioSelecionado.titulo#</cfoutput>
        </h1>
        <div class="challenge-copy">
            <cfoutput>#qDesafioSelecionado.descricao#</cfoutput>
        </div>
        <cfoutput>
            <div class="challenge-status-row">
                <div class="challenge-badge-info">
                    <i class="fa-solid fa-calendar-check"></i>
                    #challengeJoinedDateLabel#
                </div>

                <cfif qMeusDesafio.tag EQ "todosantodia" AND Usuario.logado AND Usuario.id GT 0>
                    <button type="button"
                            class="challenge-refresh-button"
                            id="btnAtualizarTodosantodia"
                            data-user-id="#Usuario.id#"
                            data-api-url="/api/strava/atualizar/?desafio=todosantodia&id_usuario=#Usuario.id#&token=jf8w3ynr73840rync848udq07yrc89q2h4nr08ync743c9r8h328f42fc8n23&debug=false&auto=false&order=desc&full=true">
                        <i class="fa-solid fa-rotate-right"></i>
                        <span>#challengeDetailPageCatalog.refresh#</span>
                    </button>
                </cfif>
            </div>
        </cfoutput>

        <cfif Usuario.logado>
            <div class="challenge-action-grid">
                <cfif qMeusDesafio.produto_desafio EQ "inscricao365vip">
                    <a href="https://chat.whatsapp.com/Ju0eZhsqh6Z9i3l5MCIOlo" target="_blank" class="btn btn-success text-center" aria-label="<cfoutput>#challengeDetailsCatalog.vipGroup#</cfoutput>">
                        <i class="fa-brands fa-whatsapp me-1"></i><cfoutput>#challengeDetailsCatalog.vipGroup#</cfoutput>
                    </a>
                <cfelseif qMeusDesafio.produto_desafio EQ "todosantodiavip">
                    <a href="https://chat.whatsapp.com/EemQIoU6sSgEoLwcRoZvzf" target="_blank" class="btn btn-success text-center" aria-label="<cfoutput>#challengeDetailsCatalog.vipGroup#</cfoutput>">
                        <i class="fa-brands fa-whatsapp me-1"></i><cfoutput>#challengeDetailsCatalog.vipGroup#</cfoutput>
                    </a>
                <cfelseif qMeusDesafio.produto_desafio EQ "todosantodia">
                    <form action="/desafio/todosantodia/inscricao/" method="post">
                        <input type="hidden" name="produto_codigo" value="todosantodiaupg"/>
                        <button type="submit" class="btn btn-warning text-center">
                            <i class="fa-regular fa-circle-up me-1"></i><cfoutput>#challengeDetailPageCatalog.beVip#</cfoutput>
                        </button>
                    </form>
                </cfif>

                <cfif qMeusDesafio.tag EQ "desafio365">
                    <a href="<cfoutput>#qDesafioSelecionado.loja#</cfoutput>" target="_blank" class="btn btn-secondary text-center" aria-label="<cfoutput>#challengeDetailPageCatalog.partnerStore#</cfoutput>">
                        <i class="fa-solid fa-basket-shopping me-1"></i><cfoutput>#challengeDetailPageCatalog.partnerStore#</cfoutput>
                    </a>
                </cfif>

                <a href="<cfoutput>#qDesafioSelecionado.hotsite#</cfoutput>" target="_blank" class="btn btn-secondary text-center" aria-label="<cfoutput>#challengeDetailsCatalog.hotsite#</cfoutput>">
                    <i class="fa-solid fa-arrow-up-right-from-square me-1"></i><cfoutput>#challengeDetailsCatalog.hotsite#</cfoutput>
                </a>
            </div>
        </cfif>
    </div>
</div>

<cfif qMeusDesafio.tag EQ "desafio365">
    <a href="/desafio/todosantodia/" class="text-decoration-none">
        <div class="challenge-detail-card mb-2">
            <div class="challenge-detail-body">
                <div class="challenge-kicker"><cfoutput>#challengeDetailPageCatalog.newChallengeKicker#</cfoutput></div>
                <div class="challenge-title mb-0"><cfoutput>#challengeDetailPageCatalog.newChallengeTitle#</cfoutput></div>
            </div>
            <img src="/assets/banner_tsd.jpg" class="challenge-detail-media" data-audience-slot="rr-challenge-detail-promo" data-audience-placement="rr-content-static-promo" data-audience-state="house" alt="<cfoutput>#appsMenuCatalog.todoSantoDiaAlt#</cfoutput>"/>
        </div>
    </a>
</cfif>

<!--- NUMEROS CONSOLIDADOS TODOSANTODIA --->

<cfif qMeusDesafio.tag EQ "todosantodia" AND qDadosDesafio.recordcount>

    <div class="row g-2 mb-2">
        <div class="col-12 col-md-6">
            <div class="challenge-stat-card">
                <div class="challenge-stat-icon"><i class="fa-solid fa-person-running"></i></div>
                <div class="challenge-stat-label"><cfoutput>#challengeDetailPageCatalog.currentStreak#</cfoutput></div>
                <div class="challenge-stat-value">
                    <cfoutput>
                        #len(trim(qDadosDesafio.sequencia_atual)) ? qDadosDesafio.sequencia_atual : 0# #val(qDadosDesafio.sequencia_atual) EQ 1 ? challengeDetailPageCatalog.daySingular : challengeDetailPageCatalog.dayPlural#
                        | #len(trim(qDadosDesafio.sequencia_atual_km)) ? numberFormat(qDadosDesafio.sequencia_atual_km, "9.9") : 0# km
                    </cfoutput>
                </div>
                <div class="challenge-stat-caption">
                    <cfoutput>#REQUEST.t("challenges.detailPage.runningSince", {"date" = qDadosDesafio.recordcount AND len(trim(qDadosDesafio.correndo_atualmente)) ? lsDateFormat(qDadosDesafio.correndo_atualmente, "dd/mm/yyyy") : "-"})#</cfoutput>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-6">
            <div class="challenge-stat-card">
                <div class="challenge-stat-icon"><i class="fa-solid fa-trophy"></i></div>
                <div class="challenge-stat-label"><cfoutput>#challengeDetailPageCatalog.bestStreak#</cfoutput></div>
                <div class="challenge-stat-value">
                    <cfoutput>#qDadosDesafio.maior_sequencia# #val(qDadosDesafio.maior_sequencia) EQ 1 ? challengeDetailPageCatalog.daySingular : challengeDetailPageCatalog.dayPlural# | #len(trim(qDadosDesafio.maior_sequencia_km)) ? numberFormat(qDadosDesafio.maior_sequencia_km, "9.9") : 0# km</cfoutput>
                </div>
                <div class="challenge-stat-caption">
                    <cfoutput>#REQUEST.t("challenges.detailPage.countingSince", {"date" = qDadosDesafio.recordcount AND len(trim(qDadosDesafio.correndo_desde)) ? lsDateFormat(qDadosDesafio.correndo_desde, "dd/mm/yyyy") : "-"})#</cfoutput>
                </div>
            </div>
        </div>
    </div>

<!--- NUMEROS CONSOLIDADOS --->

<cfelse>

    <div class="row g-2 mb-2">
        <div class="col-6">
            <div class="challenge-stat-card">
                <div class="challenge-stat-icon"><i class="fa-regular fa-calendar-days"></i></div>
                <div class="challenge-stat-label"><cfoutput>#challengeDetailsCatalog.activeDays#</cfoutput></div>
                <div class="challenge-stat-value">
                    <cfoutput>#Len(trim(qResumoDesafioHomologado.total)) ? qResumoDesafioHomologado.total : '0'#/<cfif qDesafioSelecionado.timeframe EQ 'periodo'>365<cfelse>#qStravaDiario.recordcount#</cfif></cfoutput>
                </div>
            </div>
        </div>
        <div class="col-6">
            <div class="challenge-stat-card">
                <div class="challenge-stat-icon"><i class="fa-solid fa-route"></i></div>
                <div class="challenge-stat-label"><cfoutput>#challengeDetailsCatalog.distanceCovered#</cfoutput></div>
                <div class="challenge-stat-value">
                    <cfoutput>#len(trim(qResumoDesafioHomologado.distance)) ? numberFormat(qResumoDesafioHomologado.distance, "9.99") : "0.00"# km</cfoutput>
                </div>
            </div>
        </div>
    </div>

</cfif>

<!--- LISTAGEM DE DIAS E ATIVIDADES --->

<cfinclude template="desafio_calendario.cfm"/>

<cfif qMeusDesafio.tag EQ "todosantodia" AND Usuario.logado AND Usuario.id GT 0>
    <script>
        window.addEventListener('load', () => {
            const refreshButton = document.getElementById('btnAtualizarTodosantodia');
            if (!refreshButton) {
                return;
            }

            const today = new Date().toISOString().slice(0, 10);
            const storageKey = 'rr_todosantodia_update_' + refreshButton.dataset.userId;
            const lastUpdate = localStorage.getItem(storageKey);

            const setDisabledForToday = () => {
                refreshButton.disabled = true;
                refreshButton.innerHTML = '<i class="fa-solid fa-check"></i><span><cfoutput>#JSStringFormat(challengeDetailPageCatalog.refreshedToday)#</cfoutput></span>';
                refreshButton.title = '<cfoutput>#JSStringFormat(challengeDetailPageCatalog.refreshDailyHint)#</cfoutput>';
            };

            if (lastUpdate === today) {
                setDisabledForToday();
                return;
            }

            refreshButton.addEventListener('click', () => {
                if (refreshButton.disabled) {
                    return;
                }

                refreshButton.disabled = true;
                refreshButton.innerHTML = '<span class="spinner-border spinner-border-sm" aria-hidden="true"></span><span><cfoutput>#JSStringFormat(challengeDetailPageCatalog.refreshing)#</cfoutput></span>';

                fetch(refreshButton.dataset.apiUrl, {
                    method: 'GET',
                    credentials: 'same-origin',
                    redirect: 'manual',
                    cache: 'no-store'
                })
                    .catch(() => {
                        // A API pode redirecionar ou retornar HTML; a resposta nao deve ser renderizada ao usuario.
                    })
                    .finally(() => {
                        localStorage.setItem(storageKey, today);
                        window.location.reload();
                    });
            });
        });
    </script>
</cfif>

<div class="row g-2 mt-0">
    <div class="col-12 col-md-8">
        <div class="challenge-section-card h-100">
            <div class="challenge-section-title"><cfoutput>#challengeDetailsCatalog.organizer#</cfoutput></div>
            <div class="row text-center align-items-center g-2">
                <cfoutput>#qDesafioSelecionado.sponsors#</cfoutput>
            </div>
        </div>
    </div>
    <div class="col-12 col-md-4">
        <div class="challenge-section-card h-100">
            <div class="challenge-section-title"><cfoutput>#challengeDetailsCatalog.backing#</cfoutput></div>
            <div class="text-center">
                <img src="/assets/logo-strava.png" class="w-100px my-2" alt="<cfoutput>#REQUEST.t('athlete.social.strava')#</cfoutput>"><br>
            </div>
        </div>
    </div>
    <div class="col-12">
        <div class="challenge-section-card">
            <div class="challenge-section-title"><cfoutput>#challengeDetailsCatalog.help#</cfoutput></div>
            <div class="challenge-support-grid">
                <a href="<cfoutput>#qDesafioSelecionado.regulamento#</cfoutput>" target="_blank" class="challenge-support-link">
                    <i class="fa-regular fa-file-lines"></i> <cfoutput>#challengeDetailsCatalog.rules#</cfoutput>
                </a>
                <a href="<cfoutput>#qDesafioSelecionado.suporte#</cfoutput>" target="_blank" class="challenge-support-link">
                    <i class="fa-brands fa-whatsapp"></i> <cfoutput>#challengeDetailsCatalog.support#</cfoutput>
                </a>
            </div>
        </div>
    </div>
</div>
