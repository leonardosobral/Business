<cfparam name="VARIABLES.adsV1BannerClassName" default="home-side-banner" />
<cfparam name="VARIABLES.adsV1BannerDeviceClass" default="ALL" />
<cfparam name="VARIABLES.adsV1BannerRegionCode" default="" />
<cfparam name="VARIABLES.adsV1BannerRoute" default="sidebar" />
<cfinclude template="runtime_config.cfm" />

<cfscript>
    VARIABLES.adsV1BannerPlacementKey =
        "rr-sidebar-banner-300x250";
    VARIABLES.adsV1BannerConfig = REQUEST.adsV1;
    VARIABLES.adsV1BannerHouseEnabled = structKeyExists(
        VARIABLES.adsV1BannerConfig,
        "housePlacements"
    ) && isArray(VARIABLES.adsV1BannerConfig.housePlacements)
        && arrayFindNoCase(
            VARIABLES.adsV1BannerConfig.housePlacements,
            VARIABLES.adsV1BannerPlacementKey
        ) GT 0;
    VARIABLES.adsV1BannerDelivery = {
        enabled = VARIABLES.adsV1BannerHouseEnabled,
        status = VARIABLES.adsV1BannerHouseEnabled
            ? "unavailable"
            : "disabled",
        campaignId = "",
        deliveryId = "",
        servedEventId = "",
        viewEventId = "",
        clickEventId = "",
        rawToken = "",
        destinationUrl = "",
        desktopImageUrl = "",
        desktopWidth = 0,
        desktopHeight = 0,
        mobileImageUrl = "",
        mobileWidth = 0,
        mobileHeight = 0,
        altText = "",
        openInNewTab = false,
        durationMs = 0,
        errorStage = ""
    };
    VARIABLES.adsV1BannerDelivered = false;
    // Route and device identify the physical position, independently of campaign.
    VARIABLES.audienceBannerSlotKey = "rr-" & lCase(VARIABLES.adsV1BannerRoute)
        & "-banner-" & lCase(VARIABLES.adsV1BannerDeviceClass);

    if (VARIABLES.adsV1BannerHouseEnabled) {
        try {
            VARIABLES.adsV1BannerService = createObject(
                "component",
                "services.AdsV1BannerDeliveryService"
            ).init(VARIABLES.adsV1BannerConfig);
            VARIABLES.adsV1BannerDelivery =
                VARIABLES.adsV1BannerService.deliver(
                    placementKey = VARIABLES.adsV1BannerPlacementKey,
                    deviceClass = uCase(trim(
                        VARIABLES.adsV1BannerDeviceClass & ""
                    )),
                    countryCode = "BR",
                    regionCode = uCase(trim(
                        VARIABLES.adsV1BannerRegionCode & ""
                    )),
                    route = lCase(trim(
                        VARIABLES.adsV1BannerRoute & ""
                    ))
                );
        } catch (any ignoredAdsV1BannerIntegrationError) {
            VARIABLES.adsV1BannerDelivery.status = "error";
            VARIABLES.adsV1BannerDelivery.errorStage = "integration";
        }
    }

    VARIABLES.adsV1BannerDeliveryValid =
        VARIABLES.adsV1BannerDelivery.status EQ "served"
        && len(trim(VARIABLES.adsV1BannerDelivery.deliveryId & ""))
        && len(trim(VARIABLES.adsV1BannerDelivery.viewEventId & ""))
        && len(trim(VARIABLES.adsV1BannerDelivery.clickEventId & ""))
        && len(trim(VARIABLES.adsV1BannerDelivery.rawToken & ""))
        && reFindNoCase(
            "^https://[^[:space:]]+$",
            VARIABLES.adsV1BannerDelivery.destinationUrl & ""
        )
        && reFindNoCase(
            "^https://[^[:space:]]+$",
            VARIABLES.adsV1BannerDelivery.desktopImageUrl & ""
        )
        && reFindNoCase(
            "^https://[^[:space:]]+$",
            VARIABLES.adsV1BannerDelivery.mobileImageUrl & ""
        )
        && val(VARIABLES.adsV1BannerDelivery.desktopWidth) GT 0
        && val(VARIABLES.adsV1BannerDelivery.desktopHeight) GT 0
        && val(VARIABLES.adsV1BannerDelivery.mobileWidth) GT 0
        && val(VARIABLES.adsV1BannerDelivery.mobileHeight) GT 0
        && len(trim(VARIABLES.adsV1BannerDelivery.altText & ""));
</cfscript>

<cfif VARIABLES.adsV1BannerDeliveryValid>
    <cfset VARIABLES.adsV1BannerSlot = {
        placementKey = VARIABLES.adsV1BannerPlacementKey,
        className = VARIABLES.adsV1BannerClassName,
        delivery = VARIABLES.adsV1BannerDelivery
    } />
    <cfinclude template="banner_slot.cfm" />
    <cfset VARIABLES.adsV1BannerDelivered = true />
    <cfinclude template="viewability.cfm" />
<cfelseif VARIABLES.adsV1BannerHouseEnabled
    AND VARIABLES.adsV1BannerDelivery.status EQ "no_candidate"
    AND lCase(trim(VARIABLES.adsV1BannerRoute)) EQ "sidebar"
    AND uCase(trim(VARIABLES.adsV1BannerDeviceClass)) EQ "DESKTOP">
    <!--- Local inventory pilot: never a delivery in the Ads engine. --->
    <cfinclude template="sidebar_house_pilot.cfm" />
<cfelse>
    <cfset VARIABLES.audienceSlot = {
        key = VARIABLES.audienceBannerSlotKey,
        placement = VARIABLES.adsV1BannerPlacementKey,
        state = !VARIABLES.adsV1BannerHouseEnabled ? "disabled" : "error",
        deliveryStatus = VARIABLES.adsV1BannerDelivery.status,
        requested = VARIABLES.adsV1BannerHouseEnabled,
        served = false
    } />
    <cfinclude template="../analytics/slot_marker.cfm" />
</cfif>
