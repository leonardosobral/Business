<!--- Keep the physical slot stable. This local piece has no campaign or billing identity. --->
<cfif NOT structKeyExists(REQUEST, "audienceSidebarHouseCssRendered")>
    <cfset REQUEST.audienceSidebarHouseCssRendered = true />
    <style>
        .home-side-banner.rr-audience-sidebar-house {
            display: none;
            box-sizing: border-box;
            width: 100%;
            max-width: 100%;
            aspect-ratio: 6 / 5;
            padding: 16px;
            border: 1px solid #fab120;
            border-radius: 8px;
            background: #fff8e6;
            color: #243041;
            text-decoration: none;
            overflow: hidden;
        }
        .rr-audience-sidebar-house__brand {
            font-size: 0.65rem;
            font-weight: 800;
            letter-spacing: 0.12em;
        }
        .home-side-banner.rr-audience-sidebar-house img {
            display: block;
            width: 100%;
            height: auto;
            aspect-ratio: 4 / 1;
            border-radius: 4px;
        }
        .rr-audience-sidebar-house__title {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            font-size: clamp(1rem, 1.6vw, 1.25rem);
            line-height: 1.2;
            font-weight: 800;
        }
        .home-side-banner.rr-audience-sidebar-house:hover {
            color: #243041;
            background: #fff0c6;
        }
        .home-side-banner.rr-audience-sidebar-house:focus-visible {
            outline: 3px solid #243041;
            outline-offset: 3px;
        }
        @media (min-width: 992px) {
            .home-side-banner.rr-audience-sidebar-house {
                display: grid;
                align-content: space-between;
                gap: 12px;
            }
        }
    </style>
</cfif>
<cfscript>
    // Reuse the existing translated destination label; no new i18n bootstrap/cache.
    VARIABLES.audienceSidebarHouseTitle = REQUEST.i18n.common.activitySidebar.marathonsBrazilAlt;
    writeOutput('<a href="/maratonas/" class="'
        & encodeForHTMLAttribute(trim(VARIABLES.adsV1BannerClassName) & ' rr-audience-sidebar-house')
        & '" data-rr-house-pilot="sidebar-marathons-300x250-v1" data-audience-slot="'
        & encodeForHTMLAttribute(VARIABLES.audienceBannerSlotKey)
        & '" data-audience-placement="'
        & encodeForHTMLAttribute(VARIABLES.adsV1BannerPlacementKey)
        & '" data-audience-media="(min-width: 992px)" data-audience-state="house"'
        & ' data-audience-requested="true" data-audience-served="false">'
        & '<span class="rr-audience-sidebar-house__brand">ROAD RUNNERS</span>'
        & '<img src="/assets/banner_maratonas.jpg" alt="" width="600" height="150" loading="lazy" decoding="async">'
        & '<span class="rr-audience-sidebar-house__title">'
        & encodeForHTML(VARIABLES.audienceSidebarHouseTitle)
        & '<span aria-hidden="true">&rarr;</span></span></a>');
</cfscript>
