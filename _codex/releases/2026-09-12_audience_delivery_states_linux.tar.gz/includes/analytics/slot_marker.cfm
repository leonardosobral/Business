<!--- Collapsed inventory records are opportunities; they have no renderable area. --->
<cfscript>
    if (structKeyExists(VARIABLES.audienceSlot, "deliveryStatus")) {
        VARIABLES.audienceSlotDeliveryStatus = lCase(trim(
            VARIABLES.audienceSlot.deliveryStatus & ""
        ));

        if (
            !VARIABLES.audienceSlot.requested
            || VARIABLES.audienceSlotDeliveryStatus EQ "disabled"
        ) {
            VARIABLES.audienceSlot.state = "disabled";
        } else if (
            VARIABLES.audienceSlotDeliveryStatus EQ "filtered_traffic"
        ) {
            VARIABLES.audienceSlot.state = "not_applicable";
        } else if (
            VARIABLES.audienceSlotDeliveryStatus EQ "no_candidate"
        ) {
            VARIABLES.audienceSlot.state = "empty";
        } else {
            VARIABLES.audienceSlot.state = "error";
        }
    }

    // Mobile banner markers may outlive their responsive AJAX wrapper. Keep
    // the physical position's existing <768px rule on the inventory marker.
    VARIABLES.audienceSlotMedia = reFind("-banner-mobile$", VARIABLES.audienceSlot.key)
        ? '(max-width: 767.98px)' : '';
    // writeOutput also supports callers already inside cfoutput.
    writeOutput('<span hidden data-audience-slot="'
        & encodeForHTMLAttribute(VARIABLES.audienceSlot.key)
        & '" data-audience-placement="'
        & encodeForHTMLAttribute(VARIABLES.audienceSlot.placement)
        & '" data-audience-media="'
        & encodeForHTMLAttribute(VARIABLES.audienceSlotMedia)
        & '" data-audience-state="'
        & encodeForHTMLAttribute(VARIABLES.audienceSlot.state)
        & '" data-audience-requested="'
        & (VARIABLES.audienceSlot.requested ? 'true' : 'false')
        & '" data-audience-served="'
        & (VARIABLES.audienceSlot.served ? 'true' : 'false') & '"></span>');
</cfscript>
