<cfset adEventListCatalog = REQUEST.i18n.search.eventList />
<cfparam name="VARIABLES.eventosAdsOnlyMobileBanner" default="false" />
<cfparam name="VARIABLES.eventosAdsRenderMobileBanner" default="true" />

<cfif structKeyExists(REQUEST, "Usuario")>
    <cfset Usuario = REQUEST.Usuario/>
<cfelse>
    <cfset Usuario = createObject("component", "includes.models.Usuario").init()/>
    <cfset REQUEST.Usuario = Usuario/>
</cfif>

<cfscript>
    VARIABLES.eventosAdsUsuarioLogado = structKeyExists(Usuario, "logado")
        && (
            isBoolean(Usuario.logado)
                ? javacast("boolean", Usuario.logado)
                : listFindNoCase("1,true,yes,sim,s", trim(Usuario.logado & "")) GT 0
        );
    VARIABLES.eventosAdsUsuarioId = VARIABLES.eventosAdsUsuarioLogado
        && structKeyExists(Usuario, "id")
        && isNumeric(Usuario.id)
            ? val(Usuario.id)
            : 0;
</cfscript>

<cfset VARIABLES.adContextUf = "" />
<cfif VARIABLES.template EQ "/" AND structKeyExists(VARIABLES, "homeContextUf") AND len(trim(VARIABLES.homeContextUf)) AND (NOT structKeyExists(VARIABLES, "homeContextFallback") OR NOT VARIABLES.homeContextFallback)>
    <cfset VARIABLES.adContextUf = uCase(trim(VARIABLES.homeContextUf)) />
<cfelseif VARIABLES.template EQ "/estado/" AND isDefined("qEventos.estado") AND len(trim(qEventos.estado))>
    <cfset VARIABLES.adContextUf = uCase(trim(qEventos.estado)) />
<cfelseif VARIABLES.template EQ "/busca/" AND len(trim(URL.estado)) AND trim(URL.estado) NEQ "BR">
    <cfset VARIABLES.adContextUf = uCase(trim(URL.estado)) />
<cfelseif VARIABLES.template EQ "/busca/" AND len(trim(URL.estados))>
    <cfset VARIABLES.adContextUf = uCase(trim(listFirst(URL.estados))) />
<cfelseif len(trim(VARIABLES.uf)) AND VARIABLES.uf NEQ "BR">
    <cfset VARIABLES.adContextUf = uCase(trim(VARIABLES.uf)) />
</cfif>
<cfinclude template="analytics/partial_context.cfm" />
<cfif VARIABLES.eventosAdsRenderMobileBanner>
<div class="d-block d-md-none mt-2 mb-3">
    <cfset VARIABLES.adsV1BannerClassName =
        "home-side-banner d-block mt-2 mb-2" />
    <cfset VARIABLES.adsV1BannerDeviceClass = "MOBILE" />
    <cfset VARIABLES.adsV1BannerRegionCode = VARIABLES.adContextUf />
    <cfset VARIABLES.adsV1BannerRoute = VARIABLES.template EQ "/busca/"
        ? "search"
        : (VARIABLES.template EQ "/estado/" ? "state" : "home") />
    <cfinclude template="ads_v1/banner_delivery.cfm" />
</div>
</cfif>

<cfif VARIABLES.eventosAdsOnlyMobileBanner>
    <cfexit method="exittemplate" />
</cfif>

<!--- Todos os spots patrocinados usam exclusivamente a selecao canonica V1. --->
<cfscript>
    include "ads_v1/runtime_config.cfm";
    VARIABLES.adsV1NativeConfig = REQUEST.adsV1;
    VARIABLES.adsV1NativeSlotDefinitions = [];
    VARIABLES.adsV1NativeDeliveredSlots = [];
    VARIABLES.adsV1NativeExcludedCampaignIds = [];
    VARIABLES.adsV1CpcConfigured = false;
    VARIABLES.adsV1HouseConfigured = false;
    VARIABLES.adsV1NativeDeviceClass = reFindNoCase(
        "mobile|android|iphone|ipad|ipod",
        structKeyExists(CGI, "HTTP_USER_AGENT")
            ? CGI.HTTP_USER_AGENT & ""
            : ""
    ) ? "MOBILE" : "DESKTOP";

    if (VARIABLES.template EQ "/") {
        VARIABLES.adsV1NativeSlotDefinitions = [
            {
                placementKey = "rr-home-upcoming-native",
                route = "home"
            },
            {
                placementKey = "rr-home-upcoming-native-secondary",
                route = "home"
            }
        ];
    } else if (VARIABLES.template EQ "/busca/") {
        VARIABLES.adsV1NativeSlotDefinitions = [{
            placementKey = "rr-search-events-native",
            route = "search"
        }];
    } else if (VARIABLES.template EQ "/estado/") {
        VARIABLES.adsV1NativeSlotDefinitions = [{
            placementKey = "rr-state-events-native",
            route = "state"
        }];
    }

    for (VARIABLES.adsV1NativeSlotDefinition in
        VARIABLES.adsV1NativeSlotDefinitions) {
        VARIABLES.adsV1NativePlacementKey = lCase(trim(
            VARIABLES.adsV1NativeSlotDefinition.placementKey & ""
        ));
        VARIABLES.adsV1NativeCpcEnabled = structKeyExists(
            VARIABLES.adsV1NativeConfig,
            "cpcPlacements"
        )
            && isArray(VARIABLES.adsV1NativeConfig.cpcPlacements)
            && arrayFindNoCase(
                VARIABLES.adsV1NativeConfig.cpcPlacements,
                VARIABLES.adsV1NativePlacementKey
            ) GT 0;
        VARIABLES.adsV1NativeHouseEnabled =
            !VARIABLES.adsV1NativeCpcEnabled
            && structKeyExists(
                VARIABLES.adsV1NativeConfig,
                "housePlacements"
            )
            && isArray(VARIABLES.adsV1NativeConfig.housePlacements)
            && arrayFindNoCase(
                VARIABLES.adsV1NativeConfig.housePlacements,
                VARIABLES.adsV1NativePlacementKey
            ) GT 0;
        VARIABLES.adsV1NativePlacementEnabled =
            VARIABLES.adsV1NativeCpcEnabled
            || VARIABLES.adsV1NativeHouseEnabled;
        VARIABLES.adsV1NativeDelivery = {
            enabled = VARIABLES.adsV1NativePlacementEnabled,
            status = VARIABLES.adsV1NativePlacementEnabled
                ? "unavailable"
                : "disabled",
            campaignId = "",
            deliveryId = "",
            servedEventId = "",
            viewEventId = "",
            clickEventId = "",
            rawToken = "",
            destinationUrl = "",
            coreEventId = 0,
            priceSnapshot = 0,
            durationMs = 0,
            errorStage = ""
        };
        VARIABLES.adsV1NativeBillingModel = "";

        if (VARIABLES.adsV1NativePlacementKey EQ
            "rr-home-upcoming-native") {
            VARIABLES.adsV1CpcConfigured =
                VARIABLES.adsV1NativeCpcEnabled;
            VARIABLES.adsV1HouseConfigured =
                VARIABLES.adsV1NativeHouseEnabled;
        }

        try {
            if (VARIABLES.adsV1NativeCpcEnabled) {
                if (!structKeyExists(VARIABLES, "adsV1CpcService")) {
                    VARIABLES.adsV1CpcService = createObject(
                        "component",
                        "services.AdsV1CpcDeliveryService"
                    ).init(VARIABLES.adsV1NativeConfig);
                }

                VARIABLES.adsV1NativeDelivery =
                    VARIABLES.adsV1CpcService.deliver(
                        placementKey =
                            VARIABLES.adsV1NativePlacementKey,
                        deviceClass =
                            VARIABLES.adsV1NativeDeviceClass,
                        countryCode = "BR",
                        regionCode = VARIABLES.adContextUf,
                        excludedCampaignIds =
                            VARIABLES.adsV1NativeExcludedCampaignIds,
                        route =
                            VARIABLES.adsV1NativeSlotDefinition.route
                    );
                VARIABLES.adsV1NativeBillingModel = "CPC";
            } else if (VARIABLES.adsV1NativeHouseEnabled) {
                if (!structKeyExists(VARIABLES, "adsV1HouseService")) {
                    VARIABLES.adsV1HouseService = createObject(
                        "component",
                        "services.AdsV1HouseDeliveryService"
                    ).init(VARIABLES.adsV1NativeConfig);
                }

                VARIABLES.adsV1NativeDelivery =
                    VARIABLES.adsV1HouseService.deliver(
                        placementKey =
                            VARIABLES.adsV1NativePlacementKey,
                        deviceClass =
                            VARIABLES.adsV1NativeDeviceClass,
                        countryCode = "BR",
                        regionCode = VARIABLES.adContextUf,
                        excludedCampaignIds =
                            VARIABLES.adsV1NativeExcludedCampaignIds,
                        route =
                            VARIABLES.adsV1NativeSlotDefinition.route
                    );
                VARIABLES.adsV1NativeBillingModel = "HOUSE";
            }
        } catch (any ignoredAdsV1NativeIntegrationError) {
            VARIABLES.adsV1NativeDelivery.status = "error";
            VARIABLES.adsV1NativeDelivery.errorStage = "integration";
        }

        VARIABLES.adsV1NativeDeliveryValid =
            VARIABLES.adsV1NativeDelivery.status EQ "served"
            && val(VARIABLES.adsV1NativeDelivery.coreEventId) GT 0
            && len(trim(
                VARIABLES.adsV1NativeDelivery.campaignId & ""
            ))
            && len(trim(
                VARIABLES.adsV1NativeDelivery.deliveryId & ""
            ))
            && len(trim(
                VARIABLES.adsV1NativeDelivery.viewEventId & ""
            ))
            && len(trim(
                VARIABLES.adsV1NativeDelivery.clickEventId & ""
            ))
            && len(trim(
                VARIABLES.adsV1NativeDelivery.rawToken & ""
            ));

        if (VARIABLES.adsV1NativeDeliveryValid) {
            arrayAppend(VARIABLES.adsV1NativeDeliveredSlots, {
                placementKey = VARIABLES.adsV1NativePlacementKey,
                route = VARIABLES.adsV1NativeSlotDefinition.route,
                billingModel = VARIABLES.adsV1NativeBillingModel,
                delivery = VARIABLES.adsV1NativeDelivery
            });
            arrayAppend(
                VARIABLES.adsV1NativeExcludedCampaignIds,
                VARIABLES.adsV1NativeDelivery.campaignId
            );
        } else {
            VARIABLES.audienceSlot = {
                key = VARIABLES.adsV1NativePlacementKey,
                placement = VARIABLES.adsV1NativePlacementKey,
                state = !VARIABLES.adsV1NativePlacementEnabled ? "disabled" : "error",
                deliveryStatus = VARIABLES.adsV1NativeDelivery.status,
                requested = VARIABLES.adsV1NativePlacementEnabled,
                served = false
            };
            include "analytics/slot_marker.cfm";
            if (VARIABLES.adsV1NativePlacementEnabled) {
                try {
                    writeLog(
                        file = "ads_v1_native",
                        type = "warning",
                        text = serializeJSON({
                            event = "ads_v1_native",
                            placement =
                                VARIABLES.adsV1NativePlacementKey,
                            route =
                                VARIABLES.adsV1NativeSlotDefinition.route,
                            status =
                                VARIABLES.adsV1NativeDelivery.status,
                            errorStage =
                                VARIABLES
                                    .adsV1NativeDelivery.errorStage
                        })
                    );
                } catch (any ignoredAdsV1NativeLogError) {
                }
            }
        }
    }
</cfscript>

<cfset REQUEST.adsV1ShadowObservation = {
    enabled = false,
    status = "disabled",
    candidate = {}
} />
<cfif
    VARIABLES.template EQ "/"
    AND structKeyExists(REQUEST, "adsV1")
    AND isStruct(REQUEST.adsV1)
    AND NOT VARIABLES.adsV1CpcConfigured
    AND NOT VARIABLES.adsV1HouseConfigured
    AND NOT structKeyExists(REQUEST, "adsV1ShadowObserved")>
    <cfset REQUEST.adsV1ShadowObserved = true />
    <cfscript>
        try {
            VARIABLES.adsV1ShadowUserAgent = structKeyExists(
                CGI,
                "HTTP_USER_AGENT"
            ) ? trim(CGI.HTTP_USER_AGENT & "") : "";
            VARIABLES.adsV1ShadowDeviceClass = reFindNoCase(
                "mobile|android|iphone|ipad|ipod",
                VARIABLES.adsV1ShadowUserAgent
            ) ? "MOBILE" : "DESKTOP";
            VARIABLES.adsV1ShadowService = createObject(
                "component",
                "services.AdsV1ShadowService"
            ).init(REQUEST.adsV1);
            REQUEST.adsV1ShadowObservation =
                VARIABLES.adsV1ShadowService.observe(
                    placementKey = "rr-home-upcoming-native",
                    deviceClass = VARIABLES.adsV1ShadowDeviceClass,
                    countryCode = "BR",
                    regionCode = VARIABLES.adContextUf,
                    userId = VARIABLES.eventosAdsUsuarioId,
                    route = "home"
                );
        } catch (any ignoredAdsV1ShadowError) {
            REQUEST.adsV1ShadowObservation = {
                enabled = true,
                status = "error",
                candidate = {}
            };

            try {
                writeLog(
                    file = "ads_v1_shadow",
                    type = "warning",
                    text = serializeJSON({
                        event = "ads_v1_shadow",
                        placement = "rr-home-upcoming-native",
                        route = "home",
                        status = "error",
                        stage = "integration"
                    })
                );
            } catch (any ignoredAdsV1ShadowLogError) {
            }
        }
    </cfscript>
</cfif>

<cfif arrayLen(VARIABLES.adsV1NativeDeliveredSlots)>
    <cfset VARIABLES.adsV1NativeRenderedCount = 0 />

    <div class="col-sm-12">
        <cfif VARIABLES.template NEQ "/">
            <div class="text-divider mt-2 opacity-75"><cfoutput>#adEventListCatalog.sponsored#</cfoutput></div>
        </cfif>

        <cfif VARIABLES.template EQ "/busca/">
            <div class="row g-2">
        </cfif>

        <cfloop
            array="#VARIABLES.adsV1NativeDeliveredSlots#"
            item="VARIABLES.adsV1NativeSlot">
            <cfinclude template="ads_v1/native_event_slot.cfm" />
        </cfloop>

        <cfinclude template="ads_v1/viewability.cfm" />

        <cfif VARIABLES.template EQ "/busca/">
            </div>
        </cfif>

        <cfif VARIABLES.template EQ "/">
            <cfset REQUEST.homeSponsoredEventsRendered = min(
                VARIABLES.adsV1NativeRenderedCount,
                2
            ) />
        </cfif>
    </div>
</cfif>
