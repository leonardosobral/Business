component output="false" hint="Loads Ads flags without sharing state across sites or requests." {
    public struct function load(string configTemplate = "../config/ads.local.cfm", string host = "") output="false" {
        var localAdsConfig = {};
        var result = {
            datasource = "runnerhub",
            environment = arguments.host CONTAINS "dev." ? "development"
                : (arguments.host CONTAINS "beta." ? "beta" : "production"),
            shadowPlacements = [], housePlacements = [],
            cpcPlacements = [], cpcCampaignIds = []
        };
        var nativePlacements = [
            "rr-home-upcoming-native", "rr-home-upcoming-native-secondary",
            "rr-search-events-native", "rr-state-events-native", "rr-sidebar-event-native"
        ];
        var allPlacements = duplicate(nativePlacements);
        var field = "";
        var value = "";
        var accepted = false;
        arrayAppend(allPlacements, "rr-sidebar-banner-300x250");

        // Relative to this component's site; Adobe CF requires a relative/logical include.
        // The template is server-owned, never a request parameter.
        // All included variables stay local to this invocation, not APPLICATION.
        try {
            if (fileExists(getDirectoryFromPath(getCurrentTemplatePath()) & arguments.configTemplate)) {
                include arguments.configTemplate;
            }
            if (!isStruct(localAdsConfig)) {
                throw(type="AdsConfig.InvalidConfig", message="Invalid Ads configuration structure");
            }
        } catch (any configError) {
            try {
                writeLog(file="ads_v1_config", type="error", text="Ads local configuration could not be loaded; request disabled.");
            } catch (any ignoredLogError) {}
            return result;
        }

        // Keep the existing settings.cfm allowlists; never broaden live eligibility.
        for (field in ["shadowPlacements", "housePlacements", "cpcPlacements", "cpcCampaignIds"]) {
            if (!structKeyExists(localAdsConfig, field) || !isArray(localAdsConfig[field])) {
                continue;
            }
            for (value in localAdsConfig[field]) {
                if (!isSimpleValue(value)) continue;
                value = lCase(trim(value & ""));
                accepted = false;
                switch (field) {
                    case "shadowPlacements":
                        accepted = value EQ "rr-home-upcoming-native";
                        break;
                    case "housePlacements":
                        accepted = arrayFindNoCase(allPlacements, value) GT 0;
                        break;
                    case "cpcPlacements":
                        accepted = arrayFindNoCase(nativePlacements, value) GT 0;
                        break;
                    case "cpcCampaignIds":
                        accepted = reFind("^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", value) GT 0;
                        break;
                }
                if (accepted && !arrayFindNoCase(result[field], value)) {
                    arrayAppend(result[field], value);
                }
            }
        }
        return result;
    }
}
