<cfset VARIABLES.homeSidebarUserLoggedIn = structKeyExists(REQUEST, "Usuario")
    AND isObject(REQUEST.Usuario)
    AND REQUEST.Usuario.logado/>
<cfset VARIABLES.profileMiniAdContextUf = ""/>

<cfif VARIABLES.homeSidebarUserLoggedIn>
<cfif NOT structKeyExists(REQUEST, "homeSidebarPromosCssLoaded")>
    <cfset REQUEST.homeSidebarPromosCssLoaded = true/>
    <style>
        .profile-next-event-flags {
            display: flex;
            flex-wrap: wrap;
            gap: 0.35rem;
            margin-top: 0.65rem;
        }

        .profile-next-event-flag {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0.34rem 0.58rem;
            border-radius: 8px;
            border: 1px solid rgba(51, 51, 51, 0.1);
            background-color: #efefef;
            color: #333333;
            font-size: 0.7rem;
            font-weight: 700;
            line-height: 1;
        }

        .profile-next-event-flag.is-sponsored {
            background-color: #fff8e6;
            border-color: rgba(250, 177, 32, 0.45);
        }
    </style>
</cfif>

<cfif structKeyExists(VARIABLES, "homeContextUf") AND len(trim(VARIABLES.homeContextUf)) AND (NOT structKeyExists(VARIABLES, "homeContextFallback") OR NOT VARIABLES.homeContextFallback)>
    <cfset VARIABLES.profileMiniAdContextUf = uCase(trim(VARIABLES.homeContextUf))/>
<cfelseif isDefined("REQUEST.Usuario.estado") AND len(trim(REQUEST.Usuario.estado)) AND REQUEST.Usuario.estado NEQ "BR">
    <cfset VARIABLES.profileMiniAdContextUf = uCase(trim(REQUEST.Usuario.estado))/>
<cfelseif isDefined("REQUEST.Usuario.uf") AND len(trim(REQUEST.Usuario.uf)) AND REQUEST.Usuario.uf NEQ "BR">
    <cfset VARIABLES.profileMiniAdContextUf = uCase(trim(REQUEST.Usuario.uf))/>
<cfelseif structKeyExists(VARIABLES, "uf") AND len(trim(VARIABLES.uf)) AND VARIABLES.uf NEQ "BR">
    <cfset VARIABLES.profileMiniAdContextUf = uCase(trim(VARIABLES.uf))/>
</cfif>

<!--- O spot lateral usa exclusivamente a entrega canonica V1. --->
<cfscript>
    include "../ads_v1/runtime_config.cfm";
    VARIABLES.homeSidebarAdsV1Config = REQUEST.adsV1;
    VARIABLES.homeSidebarAdsV1Placement =
        "rr-sidebar-event-native";
    VARIABLES.homeSidebarAdsV1CpcEnabled = structKeyExists(
        VARIABLES.homeSidebarAdsV1Config,
        "cpcPlacements"
    )
        && isArray(VARIABLES.homeSidebarAdsV1Config.cpcPlacements)
        && arrayFindNoCase(
            VARIABLES.homeSidebarAdsV1Config.cpcPlacements,
            VARIABLES.homeSidebarAdsV1Placement
        ) GT 0
        && structKeyExists(
            VARIABLES.homeSidebarAdsV1Config,
            "cpcCampaignIds"
        )
        && isArray(VARIABLES.homeSidebarAdsV1Config.cpcCampaignIds)
        && arrayLen(VARIABLES.homeSidebarAdsV1Config.cpcCampaignIds) GT 0;
    VARIABLES.homeSidebarAdsV1HouseEnabled =
        !VARIABLES.homeSidebarAdsV1CpcEnabled
        && structKeyExists(
            VARIABLES.homeSidebarAdsV1Config,
            "housePlacements"
        )
        && isArray(VARIABLES.homeSidebarAdsV1Config.housePlacements)
        && arrayFindNoCase(
            VARIABLES.homeSidebarAdsV1Config.housePlacements,
            VARIABLES.homeSidebarAdsV1Placement
        ) GT 0;
    VARIABLES.homeSidebarAdsV1Enabled =
        VARIABLES.homeSidebarAdsV1CpcEnabled
        || VARIABLES.homeSidebarAdsV1HouseEnabled;
    VARIABLES.homeSidebarAdsV1BillingModel = "";
    VARIABLES.homeSidebarAdsV1Delivery = {
        enabled = VARIABLES.homeSidebarAdsV1Enabled,
        status = VARIABLES.homeSidebarAdsV1Enabled
            ? "unavailable"
            : "disabled",
        campaignId = "",
        deliveryId = "",
        servedEventId = "",
        viewEventId = "",
        clickEventId = "",
        rawToken = "",
        destinationUrl = "",
        coreEventId = 0,
        priceSnapshot = 0,
        durationMs = 0,
        errorStage = ""
    };
    VARIABLES.homeSidebarAdsV1DeviceClass = reFindNoCase(
        "mobile|android|iphone|ipad|ipod",
        structKeyExists(CGI, "HTTP_USER_AGENT")
            ? CGI.HTTP_USER_AGENT & ""
            : ""
    ) ? "MOBILE" : "DESKTOP";

    try {
        if (VARIABLES.homeSidebarAdsV1CpcEnabled) {
            VARIABLES.homeSidebarAdsV1Service = createObject(
                "component",
                "services.AdsV1CpcDeliveryService"
            ).init(VARIABLES.homeSidebarAdsV1Config);
            VARIABLES.homeSidebarAdsV1Delivery =
                VARIABLES.homeSidebarAdsV1Service.deliver(
                    placementKey =
                        VARIABLES.homeSidebarAdsV1Placement,
                    deviceClass =
                        VARIABLES.homeSidebarAdsV1DeviceClass,
                    countryCode = "BR",
                    regionCode = VARIABLES.profileMiniAdContextUf,
                    excludedCampaignIds = [],
                    route = "sidebar"
                );
            VARIABLES.homeSidebarAdsV1BillingModel = "CPC";
        } else if (VARIABLES.homeSidebarAdsV1HouseEnabled) {
            VARIABLES.homeSidebarAdsV1Service = createObject(
                "component",
                "services.AdsV1HouseDeliveryService"
            ).init(VARIABLES.homeSidebarAdsV1Config);
            VARIABLES.homeSidebarAdsV1Delivery =
                VARIABLES.homeSidebarAdsV1Service.deliver(
                    placementKey =
                        VARIABLES.homeSidebarAdsV1Placement,
                    deviceClass =
                        VARIABLES.homeSidebarAdsV1DeviceClass,
                    countryCode = "BR",
                    regionCode = VARIABLES.profileMiniAdContextUf,
                    excludedCampaignIds = [],
                    route = "sidebar"
                );
            VARIABLES.homeSidebarAdsV1BillingModel = "HOUSE";
        }
    } catch (any ignoredHomeSidebarAdsV1Error) {
        VARIABLES.homeSidebarAdsV1Delivery.status = "error";
        VARIABLES.homeSidebarAdsV1Delivery.errorStage = "integration";
    }

    VARIABLES.homeSidebarAdsV1DeliveryValid =
        VARIABLES.homeSidebarAdsV1Delivery.status EQ "served"
        && val(VARIABLES.homeSidebarAdsV1Delivery.coreEventId) GT 0
        && len(trim(
            VARIABLES.homeSidebarAdsV1Delivery.deliveryId & ""
        ))
        && len(trim(
            VARIABLES.homeSidebarAdsV1Delivery.viewEventId & ""
        ))
        && len(trim(
            VARIABLES.homeSidebarAdsV1Delivery.clickEventId & ""
        ))
        && len(trim(
            VARIABLES.homeSidebarAdsV1Delivery.rawToken & ""
        ));
</cfscript>

<cfif VARIABLES.homeSidebarAdsV1DeliveryValid>
    <cfset VARIABLES.adsV1NativeRenderedCount = 0 />
    <cfset VARIABLES.adsV1NativeSlot = {
        placementKey = VARIABLES.homeSidebarAdsV1Placement,
        route = "sidebar",
        billingModel = VARIABLES.homeSidebarAdsV1BillingModel,
        delivery = VARIABLES.homeSidebarAdsV1Delivery
    } />
    <cfinclude template="../ads_v1/native_event_slot.cfm" />
    <cfinclude template="../ads_v1/viewability.cfm" />
<cfelse>
    <cfset VARIABLES.audienceSlot = {
        key = VARIABLES.homeSidebarAdsV1Placement,
        placement = VARIABLES.homeSidebarAdsV1Placement,
        state = !VARIABLES.homeSidebarAdsV1Enabled ? "disabled" : (VARIABLES.homeSidebarAdsV1Delivery.status EQ "error" ? "error" : "empty"),
        requested = VARIABLES.homeSidebarAdsV1Enabled,
        served = false
    } />
    <cfinclude template="../analytics/slot_marker.cfm" />
</cfif>

<cfelse>
    <cfset VARIABLES.audienceSlot = { key = "rr-sidebar-event-native", placement = "rr-sidebar-event-native", state = "not_applicable", requested = false, served = false } />
    <cfinclude template="../analytics/slot_marker.cfm" />
</cfif>

<cfset VARIABLES.adsV1BannerClassName = "home-side-banner mt-2 mb-2" />
<cfset VARIABLES.adsV1BannerDeviceClass = "DESKTOP" />
<cfset VARIABLES.adsV1BannerRegionCode = VARIABLES.profileMiniAdContextUf />
<cfset VARIABLES.adsV1BannerRoute = "sidebar" />
<cfinclude template="../ads_v1/banner_delivery.cfm" />
