<cfscript>
// The service includes its own site's config, not shared APPLICATION.
// All placements in one page/partial use the same request snapshot.
if (!structKeyExists(REQUEST, "adsV1")) {
    REQUEST.adsV1 = createObject("component", "services.AdsV1ConfigService").load(
        host = structKeyExists(CGI, "HTTP_HOST") ? CGI.HTTP_HOST & "" : ""
    );
}
</cfscript>
